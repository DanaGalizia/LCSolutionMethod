function e = fn_ekap(kap,kapin,PsiA,ns,szcm,cm)
%
% This function undertakes the multiplication of basis functions by FE
% coefficients to obtain e.
% 
% Inputs:
%   kap     vector of coefficients for candidate FE solution
%   kapin   see description in fn_e.m
%   PsiA    values of basis functions
%   ns      number of different states to compute e for
%   szcm    number of vectors in cm
%   cm      indices corresponding to all possible vectors (x1,x2,x3) where
%               xj=1 or 2.
%
% Outputs:
%   e       values of e
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”
%
% NOTE: This function was converted to the mex-function fn_ekap_mex using
% MATLAB Coder in order to speed up computation. As such, it will only
% actually be used if the fn_e.m is altered.

%%

nvr = 3;

e = zeros(1,ns);
for k = 1:szcm      % for each
       
    kapPsik = kap(kapin(k,:)).';
    for j = 1:nvr
        kapPsik = kapPsik.*PsiA(j,:,cm(j,1,k));
    end
    
    e = e + kapPsik;
end