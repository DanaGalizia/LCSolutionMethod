% This file contains code to solve the model in Section 5 of Galizia,
% "Solving Rational Expectations Models Featuring Limit Cycles (or 
% Chaos) Using Perturbation Methods" using the finite element method.
%
% Note: the following functions must be in the same directory in order to
% run this script (see CodeDescription.pdf for descriptions):
%
%   - fn_cm.m
%   - fn_W.m
%   - fn_Obj.m
%   - fn_Psi.m
%   - fn_PsiA.m
%   - fn_e.m
%   - fn_ekap_mex.mexw64 (based on fn_ekap.m)
%   - fn_R.m
%   - fn_ebnd.m
%   - fn_spen.m
%   - fn_Om.m
%   - fn_BGPFE_EulErr.m
%   - fn_BGPEx_prsStr.m
%   - fn_BGPEx_SS.m
%   - legzo.m
%
% Required data files:
%   - pars_mu.mat
%   - kap_20_20_15.mat
%   - GH.mat
%   - LCvc.mat

%%
clearvars

usepr = 1;  % 1 = use parallel pool (if available)


%% parameters

I = 20;     % number of X elements
J = 20;     % number of Y elements
K = 15;     % number of M elements
LH = 10;    % number of points in Gauss-Hermite quadrature
LL = 3;     % number of points in Gauss-Legendre quadrature

Xrg = [7.42,7.57]; % grid range for X
Yrg = [.93,.995]; % grid range for Y
mu_prbrg = [.001,.999]; % grid range for mu, expressed in percentiles of distribution


ldin = 1;   % 1 = initialize with saved solution; 0 = use SS;
flld = 'kap_20_20_15'; % file name of existing solution to load (used if ldin==1)

reslv = 0;  % 1 = re-solve model; 0 = just obtain model outputs

svpr = 1*reslv;   % 1 = save solution; 0 = don't
flsv = ['kap_' num2str(I) '_' num2str(J) '_' num2str(K) '_4'];  % file name to save solution

prfl = 'pars_mu'; % file containing parameters from mu-shock model

svoutput = 0;   % 1 = save output (Euler errors, policy functions, etc.)

% tolerances for optimization routine
FuncTol = 1e-5;
OptTol = 1e-5;

nsim = 15000;    % number of Monte Carlo simulations for each Euler error


%% Grids

load(prfl)  % load parameters (contained in struct p)

nvr = 3;    % number of state variables
GrX = linspace(Xrg(1),Xrg(2),I).';  % gridpoints for X
GrY = linspace(Yrg(1),Yrg(2),J)';   % gridpoints for Y

Grprb = norminv(linspace(mu_prbrg(1),mu_prbrg(2),K)).'; % quantile grid
std_mu = p.sigmu/sqrt(1-p.rhomu^2); % unconditional s.d. of mu process
GrM = tanh(std_mu*Grprb);   % grid for transformed mu (M)

% augment gridpoints with slightly out of bounds ones (useful in later
% parts of the code)
Gr = {GrX;GrY;GrM};
fct = .001;     % factor to multiply initial first and last grid increments
                %       by to get augmented gridponts
dGr = cell(nvr,1);
Grvc = [];  % vector to hold augmented grid
dGrvc = []; % vector to hold grid sizes for augmented grid
for j = 1:nvr
    Grj = Gr{j};
    dGrj = diff(Grj);
    Gr{j} = [Grj(1)-fct*dGrj(1);Grj;Grj(end)+fct*dGrj(end)];
    dGr{j} = diff(Gr{j});
    
    Grvc = [Grvc;Gr{j}];
    dGrvc = [dGrvc;dGr{j}];
end


%% THIS BLOCK IS USED TO START UP THE PARALLEL POOL (IF IT EXISTS).

if usepr == 1
    v = ver;
    parexst = any(strcmp({v.Name}, 'Parallel Computing Toolbox'));
    if parexst
        pool = gcp('nocreate');
        if isempty(pool)
            pool = parpool();
        end
    end
end

%% Get quadrature weights/abscissae

% Gauss-Hermite
load GH     % file containing G-H quadrature nodes and weights
% nodes/weights for chosen number of nodes:
Hfld = ['GH' num2str(LH)];  
wH = GH.(Hfld).wq;
pH = reshape(GH.(Hfld).pq,1,1,[]);

% Gauss-Legendre
[pL,wL] = legzo(LL);    % call function to get G-L nodes and weights


%% Set-up

IJK = [I,J,K];

% Indices corresponding to all possible vectors (x1,x2,x3) where xj=1 or 2.
% Useful for computing FE given coefficients.
cm = fn_cm(nvr);
szcm = size(cm,3);

% Collect variables needed to evaluate policy function into structs
OP_.nvr = nvr; 
OP_.Grvc = Grvc;
OP_.dGrvc = dGrvc;
OP_.IJK = IJK;
OP = OP_;
OP.cm = cm;
OP.szcm = szcm; 

% Variables needed to get integration weights for objective function
OP.Gr = Gr;
OP.LL = LL;
OP.wL = wL;
OP.pL = pL; 

% Variables needed to compute objective function
OP.LH = LH; 
OP.wH = wH;
OP.pH = pH; 

[OP,W,sgr,ijk] = fn_W(OP);  % get reduced-form weights/gridpoints

%% Additional model parameters

betTh = p.e_^(-p.phie)/(1+(1-p.e_)*p.phi0*p.Phi0);
p.betTh = betTh;
prs = fn_BGPEx_prsStr(p,'StoV');

% steady state values
argSS = fn_BGPEx_SS(prs);
X_ = argSS(1);
Y_ = argSS(2);
y_ = [X_;Y_];


%% initialize solution

if ldin == 1        % if using saved solution
    
    % Set up array of states made up of gridpoint nodes (using current
    % gridpoints, not saved ones).
    s = zeros(OP.szijk,nvr);
    for j = 1:nvr
        Grj = Gr{j};
        Grj = Grj(2:end-1);
        s(:,j) = Grj(ijk(:,j));
    end
    s = s.';
    
    load(flld)      % load file with saved solution
    
    % Obtain e at each of the current "gridpoint-node states" but using the
    % saved solution (with the saved gridpoints). Since, at a
    % gridpoint-node state, e exactly equals the associated value of kap,
    % this gives us the kap implied by the saved solution (which could be
    % for any arbitrary set of gridpoints) but with the current gridpoints.
    kap0 = fn_e(s,kapsv,OP_sv.Grvc,OP_sv.dGrvc,OP_sv.IJK,OP.szcm,OP.cm).';
        
else    % if not using saved solution, initialize with steady state e
    
    kap0 = p.e_*ones(OP.szijk,1);
end

% double check to make sure initial solution always has e>0
kap0 = max(kap0,0.001);

%% Get solution

if reslv == 1       % if re-solving the model
    % This is a backup file to periodically store the best solution so far
    % during optimization in case something goes wrong or we need to stop
    % optimization for some reason. Need to delete any previously existing
    % copies of the file.
    if isfile('kapOpt_backup.mat')
        delete kapOpt_backup.mat
    end
    
    tkap0 = log(kap0);  % optimize in logs to make sure we always have e>0
    
    % set optimization options
    options = optimoptions('fsolve','Display','iter','MaxIterations',1000,...
        'MaxFunctionEvaluations',500*OP.szijk,'Algorithm','trust-region',...
        'FunctionTolerance',FuncTol,'OptimalityTolerance',OptTol);
    
    % norm of objective at initial solution
    OP.infval = norm(fn_Obj(tkap0,p,OP,W,sgr));
    
    % Objective function fn_Obj has persistent variables (used for 
    % occasional display of status and backing up). Need to clear those
    % before we start.
    clear fn_Obj
    
    % optimize solution
    tkap1 = fsolve(@(tkap) fn_Obj(tkap,p,OP,W,sgr),tkap0,options);
    kap1 = exp(tkap1); % convert solution back to levels from logs

else    % if not re-solving, just set "new" solution to old one
    kap1 = kap0;
    tkap1 = log(kap1);
end

obj = fn_Obj(tkap1,p,OP,W,sgr); % value of objective function at new solution


%% Save solution if required

if svpr == 1
    if isfile([flsv '.mat'])
        j = 0;
        flex = true;
        while flex
            j = j+1;
            flj = [flsv '(' num2str(j) ')'];
            flex = isfile([flj '.mat']);
        end
        qans = questdlg(['File with name ''' flsv ''' already exists. Save as ''' flj ''' instead?'],...
            'File Already Exists',...
            'Yes','Overwrite','Don''t Save','Yes');
        switch qans
            case 'Yes'
                kapsv = kap1;
                OP_sv = OP_;
                save(flj,'kapsv','OP_sv')
            case 'Overwrite'
                kapsv = kap1;
                OP_sv = OP_;
                save(flsv,'kapsv','OP_sv')
        end
    else
        kapsv = kap1;
        OP_sv = OP_;
        save(flsv,'kapsv','OP_sv')
    end
end


%% Euler errors

% load file containing relevant information for computing Euler errors
load LCvc 

nerr = size(yLvc,2)/2;  % number of Euler errors to be computed

% state-space gridpoints to compute Euler errors at
XLvc = linspace(Xrg(1),Xrg(2),nerr);
YLvc = linspace(Yrg(1),Yrg(2),nerr);

% set up gridpoints for transversal cuts
Xhld = X_;
Yhld = Y_;
yLvc = [XLvc,Xhld*ones(1,nerr);Yhld*ones(1,nerr),YLvc];

tvc = zeros(1,2*nerr);  % we'll feed in zeros for exogenous stochastic variables

% draw innovations for Monte Carlo Euler error
sd = 1546032;
rng(sd)
epsim = randn(1,nsim);

% call function to compute errors
[errvc,~] = fn_BGPFE_EulErr(yLvc,tvc,epsim,kap1,p,OP);

% Split errors into transversal cuts (one for X, one for Y)
errvcX = errvc(1:nerr);
errvcY = errvc(nerr+1:end);


%% Policy function cuts 

spolfn = [yLvc;zeros(1,2*nerr)]; % states for policy function cuts

% call function to get e at each state
epolfn = fn_ebnd(spolfn,kap1,p,OP.Grvc,OP.dGrvc,OP.IJK,OP.szcm,OP.cm);

% Split policy functions into transversal cuts (one for X, one for Y)
epolX = epolfn(1:nerr);
epolY = epolfn(nerr+1:end);


%% If required, save information for use by BGPEx.m

if svoutput == 1
    
    errvcX_FE = errvcX;
    errvcY_FE = errvcY;
    XLvc_FE = XLvc;
    YLvc_FE = YLvc;
    epolX_FE = epolX;
    epolY_FE = epolY;

    save EE_FE errvcX_FE errvcY_FE XLvc_FE YLvc_FE epolX_FE epolY_FE
end








