function [OP,W,sgr,ijk] = fn_W(OP)
%
% This function computes reduced-form weights and associated gridpoints, as
% well as several other variables that will be useful in computing the FE
% solution.
% 
% Inputs:
%   OP      struct containing relevant parameters of the set-up
%
% Outputs:
%   OP      updated struct with some additional parameters added
%   W       array of reduced-form weights; each row is a vec(W_ijk)' for
%               a different grid location (i,j,k) (see equation (A.5) in
%               Online Appendix)
%   sgr     array of gridpoints associated with reduced-form weights; each
%               column is a value of [X~_{i,l}; Y~_{j,m}; M~_{k,n}] for a
%               different grid location (i,j,k) and different combination
%               of Gauss-Legendre nodes (l,m,n) (see definition of B~_{i,l}
%               on p.4 of Online Appendix)
%   ijk     indices of grid locations (i,j,k); each row is a different
%               combination of (i,j,k), with one row per grid location
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%%

nvr = OP.nvr;   % nubmer of state variables

%% compute vectors q and r for each basis function

q = cell(nvr,1);    % coefficient on p in definition of B~_{i,l} (see p.4
                        % of Online Appendix)
r = cell(nvr,1);    % constant term in definition of B~_{i,l} (see p.4 of
                        % Online Appendix)

for j = 1:nvr   % for each state variable j
    Grj = OP.Gr{j};     % gridpoints for j-th state variable
    
    A0 = Grj(1:end-2);  % lower bound of range for each basis function
    A1 = Grj(3:end);    % upper bound of range for each basis function
    
    q{j} = (A1-A0)/2;
    r{j} = (A1+A0)/2;
end

%% create mesh of i,j,k indices

tmp = [1,cumprod(OP.IJK(1:end-1))];
szijk = prod(OP.IJK);
ijk = zeros(szijk,nvr);
for j = 1:nvr
    vc = (1:OP.IJK(j))';
    kk = OP.IJK(j)*tmp(j);
    ijk(:,j) = repmat(kron(vc,ones(tmp(j),1)),szijk/kk,1);
end

%% create mesh of Gauss-Legendre weights and abscissae (w,p)

szw = OP.LL^nvr;
w = zeros(szw,nvr);
p = zeros(szw,nvr);
for j = 1:nvr
    w(:,j) = repmat(kron(OP.wL,ones(OP.LL^(j-1),1)),OP.LL^(nvr-j),1);
    p(:,j) = repmat(kron(OP.pL,ones(OP.LL^(j-1),1)),OP.LL^(nvr-j),1);
end
w = prod(w,2).';
p = p.';

%% Reduced-form Weights and state gridpoints

W = zeros(szijk,szw);
sgr = zeros(nvr,szw,szijk);
for k = 1:szijk
    ijkk = ijk(k,:);
    pk = p;
    qk = q;
    rk = r;
    sk = zeros(nvr,szw);
    
    for j = 1:nvr
        qj = qk{j};
        rj = rk{j};
        sk(j,:) = qj(ijkk(j))*pk(j,:)+rj(ijkk(j));
    end
    Psi = fn_Psi(sk,ijkk',OP.Gr);
    W(k,:) = w.*Psi;
    sgr(:,:,k) = sk;
end

OP.szw = szw;
OP.szijk = szijk;
