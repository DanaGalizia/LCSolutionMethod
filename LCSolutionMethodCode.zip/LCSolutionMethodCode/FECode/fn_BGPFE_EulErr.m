function [errvc,e] = fn_BGPFE_EulErr(yvc,tvc,epvc,kap,p,OP)
%
% This function computes Euler errors at each state vector contained in
% Stfn.
% 
% Inputs:
%   yvc         ny-by-J matrix, where each column represents a vector of
%                   date-t endogenous state variables (y)
%   tvc         nt-by-J matrix, where each column represents a vector of
%                   date-t exogenous state variables (th)
%   epvc        nt-by-K matrix, where each column is a simulated vector
%                   of innovations to the stochastic processes at t+1
%   prs         vector of parameter values
%   cfcl        Taylor coefficients from "collapsed" solution
%   OP          struct containing other model variables
%
% Outputs:
%   errvc       J-by-1 vector of Euler errors
%
% For Galizia (2020), �Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods�

%% Initialize

J = size(yvc,2);    % number of Euler errors to be computed
K = size(epvc,2);   % number of simulations

rhomu = p.rhomu; % autocorrelations
sigmu = p.sigmu; % s.d.'s of innovations


%% Compute errors

Yp = zeros(1,J);
e = zeros(1,J);
EOmp = zeros(1,J);

Grvc = OP.Grvc;
dGrvc = OP.dGrvc;
IJK = OP.IJK;
szcm = OP.szcm;
cm = OP.cm;

parfor i = 1:J      % for each state vector
    
    yi = yvc(:,i);    % extract i-th endogenous state vector
    ti = tvc(:,i);    % extract i-th exogenous state vector
    Mi = tanh(ti);
    
    si = [yi;Mi];
    
    ei = fn_ebnd(si,kap,p,Grvc,dGrvc,IJK,szcm,cm);
    ypi = fn_spen(ei,si,p);    
    tpi = rhomu.*ti + sigmu.*epvc;
    Mpi = tanh(tpi);
    spi = [repmat(ypi,1,K);Mpi];
    Omp = fn_Om(spi,kap,p,OP);
    
    EOmp(i) = mean(Omp,2);
    e(i) = ei;
    Yp(i) = ypi(2);
end


H = yvc(1,:)/(1-p.del) + (1-p.psi/(1-p.del))*yvc(2,:);
Hp = yvc(1,:) + Yp;

e_ = p.e_;
Phi = p.Phi0*exp((p.Phi2/p.Phi0)*(e-e_).^2/2 + (p.Phi3/p.Phi0)*(e-e_).^3/6);

Q = p.betTh*(1+p.phi0*(1-e).*Phi);

errvc = (((Q.*EOmp)./exp(tvc)).^(-1/p.om) + p.gam*H)./Hp - 1;




