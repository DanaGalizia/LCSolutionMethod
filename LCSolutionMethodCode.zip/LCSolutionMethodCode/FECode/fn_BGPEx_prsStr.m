function [prsout,pnms] = fn_BGPEx_prsStr(prs,dir)
%
% This function converts parameters from vector to struct format or vice
% versa.
% 
% Inputs:
%   prs         vector or struct of parameter values
%   dir         direction of conversion; 'VtoS' = vector to struct; 'StoV'
%               = struct to vector; 'nms' = just return cell array of
%               parameter names
%
% Outputs:
%   prsout      struct or vector of parameter values
%   pnms        cell array of parameter names
%
% For Galizia (2020), �Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods�

%%

% cell array of parameter names
pnms = {    'del';   ...     % 1
            'al';    ...     % 2
            'e_';    ...     % 3
            'om';    ...     % 4
            'gam';   ...     % 5
            'psi';   ...     % 6
            'phie';  ...     % 7
            'phi0';  ...     % 8
            'Phi0';  ...     % 9
            'Phi2';  ...     % 10
            'Phi3';  ...     % 11
            'rhoz';  ...     % 12
            'sigz';  ...     % 13
            'rhomu'; ...     % 14
            'sigmu'; ...     % 15
            };

npr = numel(pnms);      % number of parameters

if strcmp(dir,'VtoS')       % for vector-to-struct direction
    
    % check for correct number of parameters in vector passed in
    if numel(prs) ~= npr
        error(['Expected ' num2str(npr) 'parameters passed in (actual = ' num2str(numel(prs)) ')'])
    end
    
    % construct struct array using variable names from pnms
    for j = 1:npr
        prsout.(pnms{j}) = prs(j);
    end
    
elseif strcmp(dir,'StoV')   % for struct-to-vector direction
    
    prsout = zeros(npr,1);  % initialize vector
    % load in parameter values
    for j = 1:npr
        prsout(j) = prs.(pnms{j});
    end
    
elseif strcmp(dir,'nms')    % for names-only case
    prsout = [];            % just set main output to empty vector
    
else                        % if dir isn't a valid choice
    error('Invalid direction.')     % report an error
end


