function e = fn_e(s,kap,Grvc,dGrvc,IJK,szcm,cm)
%
% This function computes the value of the policy function for e for given
% states and a candidate FE solution.
% 
% Inputs:
%   s       matrix with nvr rows, where each column is a different state
%               (X,Y,M)
%   kap     vector of coefficients for candidate FE solution
%   Grvc    augmented state grid (see definition in BGP_FE.m) in vector
%               form
%   dGrvc   grid increments for augmented state grid
%   IJK     vector containing number of gridpoints for each state
%   szcm    number of vectors in cm
%   cm      indices corresponding to all possible vectors (x1,x2,x3) where
%               xj=1 or 2.
%
% Outputs:
%   e       values of e at each given state as implied by candidate FE
%               solution
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%% Initial values

nvr = 3;
ns = size(s,2);

% locations in Grvc of start and end gridpoints for each individual state
Grstrt = cumsum([1,IJK(1:2)+2]);
Grend = cumsum(IJK+2);
dGrstrt = cumsum([1,IJK(1:2)+1]);
dGrend = cumsum(IJK+1);

%% find grid locations

Grin0 = zeros(nvr,ns);  % array to hold indices of lower bounds of grid ranges in Gr vectors
for j = 1:nvr   % for each state variable
    
    Grj = Grvc(Grstrt(j):Grend(j)); % gridpoints for this state variable
    
    % for state variables < min gridpoint, set equal to min gridpoint.
    % (Note: we only consider "true" gridpoints, not the augmented +/- eps
    % ones. This is why we use the index 2 here, not 1.)
    s(j,:) = max(s(j,:),Grj(2));
    
    % For state variables > max gridpoint, set equal to max gridpoint.
    % (Note: we only consider "true" gridpoints, not the augmented +/- eps
    % ones. This is why we use the index end-1 here, not end.)
    oob = s(j,:)>=Grj(end-1);
    s(j,oob) = Grj(end-1)-diff(Grj(end-1:end));
    
    % find largest gridpoint in Grj less than or equal to state variable
    dsc = discretize(s(j,:),Grj);
    Grin0(j,:) = dsc;
    
    s(j,oob) = Grj(end-1);
    
end

% This computes the linear indices of kap associated with the relevant
% elements for each state in s. Since basis functions for a given state are
% non-zero only for szcm = 2^3 = 8 basis functions, the 8 indices contained
% in each column of kapin give the indices of the 8 elements of kap
% corresponding to those 8 basis functions. We do this because, for a given
% state, only a small number of the elements of kap will actually be
% multiplying non-zero basis functions. When it comes time to do this
% multiplication, it is much faster to only multiply the non-zero elements.
cp = [1,cumprod(IJK(1:end-1))].';
tmp = cp.*(Grin0 + cm - 3);
kapin = ones(szcm,ns) + reshape(sum(tmp,1),ns,szcm).';


%% Compute necessary basis functions

PsiA = zeros(nvr,ns,2);

for j = 1:nvr   % for each state variable
    
    Grj = Grvc(Grstrt(j):Grend(j)); % grid for this state variable
    dGrj = dGrvc(dGrstrt(j):dGrend(j));   % differences in gridpoints
    
    A1 = Grj(Grin0(j,:)).';
    dA = dGrj(Grin0(j,:)).';
    A2 = Grj(Grin0(j,:)+1).';
    
    PsiA1j = fn_PsiA(s(j,:),A2,dA,true);      % left element
    PsiA2j = fn_PsiA(s(j,:),A1,dA,false);      % right element
        
    PsiA(j,:,:) = cat(3,PsiA1j,PsiA2j);
    
end


%% Compute e

% Call mex function to do final stage of multiplying each relevant basis
% function by the appropriate elements of kap.
e = fn_ekap_mex(kap,kapin,PsiA,ns,szcm,cm); 

% NOTE: If the above function does not exist, or if it does exist but was 
% compiled for a different architecture/operating system, this step will
% cause an error. You can either replace the above call with 
%
%       e = fn_ekap(kap,kapin,PsiA,ns,szcm,cm)
%
% which uses the m-function version of this code rather than the
% mex-function version, or else you can use MATLAB Coder to compile fn_ekap
% into the appropriate mex file for your system. While your mileage may
% vary, the mex-file version leads to speed gains for this task on the
% order of 30%.






