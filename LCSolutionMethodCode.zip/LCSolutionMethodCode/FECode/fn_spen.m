function spen = fn_spen(e,s,p)
%
% This function computes the value of the endogenous state (X,Y) next
% period given the current state s and the current e.
% 
% Inputs:
%   e       N-D matrix with 1 row giving current values of e
%   s       N-D matrix with nvr rows and remaining dimensions the same as
%               e, where each column is a different current state (X,Y,M)
%   p       struct containing model parameters
%
% Outputs:
%   spen    endogenous state next period
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%%

sze = size(e);
if sze(1) ~= 1
    error('The first dimension of e must be 1.')
end

% This will be used to slice the rows of s to extract the array for Y.
% This is necessary since s has an arbitrary number of dimensions, and we
% want to preserve these (e.g., Y should have the same 2nd, 3rd, 4th, etc.,
% dimensions as s).
vY = repmat({':'},ndims(s),1);
vY{1} = 2;

spen = zeros([2,sze(2:end)]);
spen(vY{:}) = max(e,0).^p.al;    % Yp
spen(1,:) = (1-p.del)*s(1,:) + p.psi*spen(2,:); %Xp