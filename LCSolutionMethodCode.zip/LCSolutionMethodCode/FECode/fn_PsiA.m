function PsiA = fn_PsiA(A,bnd,sz,left)
%
% This function computes the value of a tent function for inputs A, where
% the relevant tent function boundary is given in bnd, the size of
% the non-zero interval of the tent function is given by sz, and the
% logical variable 'left' is true if using the left one of the two
% overlapping elements (i.e., the tent function for which A is LARGER than
% the peak, in which case 'bnd' is the upper bound of the tent function
% interval), and equal to false if using the right one (i.e., the tent
% function for which A is SMALLER than the peak, in which case 'bnd' is the
% lower bound of the tent function interval).
% 
% Inputs:
%   A       N-D array of tent function inputs
%   bnd     array of same size as A, where bnd(i) is the relevant boundary
%               to use with input A(i)
%   sz      array of same size as A, where sz(i) is size of the non-zero
%               interval of the tent function used with input A(i)
%   left    logical scalar, = true if bnd > A, = false if bnd < A. NOTE:
%               This property should hold element-wise for ALL elements of
%               A. This should be ensured by the calling function (it's not
%               checked here).
%
% Outputs:
%   PsiA    N-D array of same size as A that gives values of tent function
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%%

if left
    PsiA = (bnd-A)./sz;
else
    PsiA = (A-bnd)./sz;
end




