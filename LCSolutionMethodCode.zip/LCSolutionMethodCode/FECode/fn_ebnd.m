function e = fn_ebnd(s,kap,p,Grvc,dGrvc,IJK,szcm,cm)
%
% This function computes the value of the policy function for e for given
% states and a candidate FE solution, subject to the constraints that
% certain endogenous variables must be positive.
% 
% Inputs:
%   s       matrix with nvr rows, where each column is a different state
%               (X,Y,M)
%   kap     vector of coefficients for candidate FE solution
%   p       struct containing model parameters
%   Grvc    augmented state grid (see definition in BGP_FE.m) in vector
%               form
%   dGrvc   grid increments for augmented state grid
%   IJK     vector containing number of gridpoints for each state
%   szcm    number of vectors in cm
%   cm      indices corresponding to all possible vectors (x1,x2,x3) where
%               xj=1 or 2.
%
% Outputs:
%   e       values of e at each given state as implied by candidate FE
%               solution
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%% Initial set-up

nvr = 3;
szs = size(s);

% if s has 3 or more dimensions, reshape to 2-D array
notmat = ~ismatrix(s);
if notmat
    s = reshape(s,nvr,[]);
end

%% Compute e

e = fn_e(s,kap,Grvc,dGrvc,IJK,szcm,cm); % unconstrained values of e

% Ypmn is the smallest value of Yp required to ensure that the argument of
% the marginal utility function is strictly positive (to machine
% precision).
iX = 1;
iY = 2;
Ypmn = -((1-p.gam/(1-p.del))*s(iX,:) - p.gam*(1-p.psi/(1-p.del))*s(iY,:)) + eps;

% Minimum admissable value of e is the one that delivers Ypmn (or just 0 if
% Ypmn is negative).
mne = max(Ypmn,0).^(1/p.al);
e = max(e,mne);

if notmat
    e = reshape(e,[1,szs(2:end)]);
end
