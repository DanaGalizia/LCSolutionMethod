function R = fn_R(s,kap,p,OP)
%
% This function computes the value of the Euler residuals at given states
% in s using the candidate FE solution contained in kap.
% 
% Inputs:
%   s       N-D matrix with nvr rows, where each column is a different
%               state (X,Y,M)
%   kap     vector of coefficients for candidate FE solution
%   p       struct containing model parameters
%   OP      struct containing other parameters
%
% Outputs:
%   R       Euler residuals at each state in s
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%% Initial set-up

nvr = size(s,1);
szs = size(s);

% if s has 3 or more dimensions, reshape to 2-D array
notmat = ~ismatrix(s);
if notmat
    s = reshape(s,nvr,[]);
end
ns = size(s,2);

%% Compute Euler residuals

% Get e at each state as implied by the candidate solution kap, subject to
% the constraints that various endogenous variables must be positive.
e =  fn_ebnd(s,kap,p,OP.Grvc,OP.dGrvc,OP.IJK,OP.szcm,OP.cm);

% Implied values of Phi and Q
Phi = p.Phi0*exp((p.Phi2/p.Phi0)*(e-p.e_).^2/2 + (p.Phi3/p.Phi0)*(e-p.e_).^3/6);
Q = p.betTh*(1+p.phi0*(1-min(e,1)).*Phi);

% Implied endogenous state vector next period
spen = fn_spen(e,s,p);

% Note: The function fn_ebnd called above ensures that c here (which is the
% argument of the marginal utility function) is always strictly positive.
c = spen(2,:) + (1-p.gam/(1-p.del))*s(1,:) - p.gam*(1-p.psi/(1-p.del))*s(2,:);
lm = c.^(-p.om); % marginal utility

% Get full state vector next period associated with "each" realization of
% the next-period shock (as given by the Gauss-Hermite quadrature nodes).
sp = zeros(nvr,ns,OP.LH);
sp(1:2,:,:) = repmat(spen,1,1,OP.LH);
sp(3,:,:) = tanh(p.rhomu*atanh(s(3,:)) + sqrt(2)*p.sigmu*OP.pH);

Omp = reshape(fn_Om(sp,kap,p,OP),ns,OP.LH); % Omega'
EOmp = (Omp*OP.wH).'; % E[Omega'] using Gauss-Hermite quadrature

% Euler errors
R = (1/sqrt(pi))*sqrt((1-s(3,:))./(1+s(3,:))).*Q.*EOmp./lm - 1;

% if original state array s was not a matrix, convert R to those dimensions
if notmat
    R = reshape(R,[1,szs(2:end)]);
end



