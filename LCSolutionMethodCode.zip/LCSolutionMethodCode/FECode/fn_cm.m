function cm = fn_cm(nvr)

%% indices corresponding to all possible vectors (x1,x2,x3) where xj=1 or 2

vc = [1;2];
nvc = numel(vc);
szcm = nvc^nvr;
cm = zeros(szcm,nvr);
for j = 1:nvr
    cm(:,j) = repmat(kron(vc,ones(nvc^(j-1),1)),nvc^(nvr-j),1);
end
cm = reshape(cm.',nvr,1,szcm);

