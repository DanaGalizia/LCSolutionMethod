function Om = fn_Om(s,kap,p,OP)
%
% This function computes the value of Omega at given states in s using the
% candidate FE solution contained in kap.
% 
% Inputs:
%   s       N-D matrix with nvr rows, where each column is a different
%               state (X,Y,M)
%   kap     vector of coefficients for candidate FE solution
%   p       struct containing model parameters
%   OP      struct containing other parameters
%
% Outputs:
%   Om       Omega at each state in s
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%%
% Get e at each state as implied by the candidate solution kap, subject to
% the constraints that various endogenous variables must be positive.
e =  fn_ebnd(s,kap,p,OP.Grvc,OP.dGrvc,OP.IJK,OP.szcm,OP.cm);

Yp = e.^p.al; % next-period Y

% This will be used to slice the rows of s to extract the arrays for X and
% Y. This is necessary since s has an arbitrary number of dimensions, and
% we want to preserve these (e.g., X should have the same 2nd, 3rd, 4th,
% etc., dimensions as s).
vX = repmat({':'},ndims(s),1);
vY = vX;
vX{1} = 1;
vY{1} = 2;

% Note: The function fn_ebnd called above ensures that c here (which is the
% argument of the marginal utility function) is always strictly positive.
c =  Yp + (1-p.gam/(1-p.del))*s(vX{:}) - p.gam*(1-p.psi/(1-p.del))*s(vY{:});
lm = c.^(-p.om); % marginal utility

Om = (e.^p.phie) .* lm; % Omega
