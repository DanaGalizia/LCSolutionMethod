function obj = fn_Obj(tkap,p,OP,W,sgr)
%
% This function computes the objective function for the finite elements
% solution method.
% 
% Inputs:
%   tkap	current candidate solution (in logs)
%   p       struct containing model parameters
%   OP      struct containing other parameters
%   W       array of reduced-form weights
%   sgr     array of gridpoints associated with reduced-form weights
%
% Outputs:
%   obj     value of objective function (vector, whose elements are all 0
%               at an actual solution)
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%%
% This initializes a persistent variable 'ncalls' that will track the number
% of times this function is called. This will be used to determine when to
% display current progress and back up solution parameters in case
% something goes wrong.
persistent ncalls
if isempty(ncalls)
    ncalls = 1;
else
    ncalls = ncalls+1;
end

%% Get objective function

kap = exp(tkap);        % convert candidate solutio from logs to levels

obj = zeros(OP.szijk,1);    % initialize objective function

parfor j = 1:OP.szijk       % for each element
    Rj = fn_R(sgr(:,:,j),kap,p,OP); % Get R at each Gauss-Legendre gridpoint
    obj(j) = W(j,:)*Rj.';           % Integrate to get objective function
end

%% Display

dspit = 50;    % Display progress each 'dspit' calls (starting with #1)
if rem(ncalls,dspit) == 1
    if isfield(OP,'infval') % We won't display on the initial call made to 
                            % find the initial norm of the the objetive
                            % function. Once we get that, the field
                            % 'infval' containing it will be added to OP.
                            % We check here for that field and only display
                            % if it's found.
        nrmobj = norm(obj);   % we'll display the norm of objective function vector
        disp(['Call # ' num2str(ncalls) ': ' num2str(OP.infval) ' - ' num2str(OP.infval-nrmobj) ...
            ' = ' num2str(nrmobj)])
    end
end

%% Save

svit = 200;     % Save backup every 'svit' calls
if rem(ncalls,svit) == 0
    if ~exist('nrmobj','var')   % If haven't already computed norm 
        nrmobj = norm(obj);
    end
    if isfile('kapOpt_backup.mat')
        load kapOpt_backup kapbck nrmobjbck
        if nrmobj<nrmobjbck
            svbackup
        end
    else
        svbackup
    end
end

%% Save function

function svbackup
    kapbck = kap;
    nrmobjbck = nrmobj;
    save kapOpt_backup kapbck nrmobjbck
end

end
