function Psi = fn_Psi(s,elin,Gr)
%
% This function computes the value of Psi_{ijk}(ss) (i.e., an individual 
% element) for given indices ijk and state ss.
% 
% Inputs:
%   s       N-D array with nvr rows, where each 1-D column slice is a
%               different state (X,Y,M)
%   elin    array of same size as s, where each 1-D column slice gives the
%               indices (i,j,k) of the Psi element to be evaluated for the
%               corresponding element of s; if instead elin is just a 
%               nvr-by-1 column vector, then the same element is used for
%               each state in s
%   Gr      nvr-by-1 cell containing the gridpoints
%
% Outputs:
%   Psi     N-D array with first dimension 1 and remaining dimensions the
%               same as s containing evaluated values of Psi
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%%

szs = size(s);
nvr = size(s,1);

% Get relevant gridpoints
A0 = zeros(szs);
A1 = zeros(szs);
A2 = zeros(szs);
for j = 1:nvr   % for each state variable
    
    Grj = Gr{j}; % grid for this state variable
    A0(j,:) = Grj(elin(j,:));   % left-most gridpoint
    A1(j,:) = Grj(elin(j,:)+1); % middle gridpoint (apex of tent function)
    A2(j,:) = Grj(elin(j,:)+2); % right-most gridpoint
    
end

PsiA = zeros(size(s)); % array to hold 3 the components (Psi_X, Psi_Y, Psi_M)
                        %  of the elements, which will be multiplied together
fl = (s<=A1);	% logical = true if state is on left side of tent function
nfl = ~fl;      % logical = true if state is on the right side of tent function

% Computation for states on left side of tent function
PsiA(fl) = max(s(fl)-A0(fl),0)./(A1(fl)-A0(fl)); 
% Computation for states on right side of tent function
PsiA(nfl) = max(A2(nfl)-s(nfl),0)./(A2(nfl)-A1(nfl));
% Multiply components together to get required element
Psi = prod(PsiA,1);

