function [cfcl,cfdet,Texpl,Dpol,Taypol,errfl] = fn_BGPEx_Sol(prs,OP,exchk)
%
% This function computes Taylor coefficients for the approximation to each
% candidate solution to the model.
% 
% Inputs:
%   prs         vector of parameter values
%   OP          struct containing other model variables
%   exchk       optional logical: true = check for explosion (default);
%                   false = don't check
%
% Outputs:
%   cfcl        Taylor coefficients from "collapsed" solution
%   cfdet       Taylor coefficients from "deterministic" solution
%
% Note: the following functions must be in the same directory in order to
% run this script (see CodeDescription.pdf for descriptions):
%
%   - fn_BGPEx_FirstOrderMat.m
%   - fn_BGPEx_prsStr.m
%   - fn_BGPEx_SS.m
%   - InvSubGen.m
%   - fn_BGPEx_XYESim.m
%   - TaylSim_tX.m
%
% For Galizia (2020), �Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods�

%% Initial calcualtions

if nargin < 3
    exchk = true;
end

p = fn_BGPEx_prsStr(prs,'VtoS');

argSS = fn_BGPEx_SS(prs); % steady state
DQ = OP.fnDQ(prs);  % derivatives of Q function

%% Candidate first-order approximations

% obtain the nW candidate first-order approximations
[Gx0,Gx1,Gt0,Gt1,Pi] = fn_BGPEx_FirstOrderMat(prs,argSS,DQ);  % get first-order matrices
[nW,~,pi_y,phi_y,pi_t,phi_t] = InvSubGen(Gx0,Gx1,Gt0,Gt1,Pi,OP.ny); % call function that returns candidate approximations

% Dpol1 will be a nSt0-by-npol-by-nW array, where, for the j-th candidate
% approximation, Dpol1(:,k,j) contains the first-order coefficients of the
% k-th function
Dpol1 = [pi_y,pi_t;phi_y,phi_t];
Dpol1 = permute(Dpol1,[2,1,3]); % transpose

% check to make sure there's exactly one candidate solution

if nargout == 6
    if nW ~=1
        errfl = 1;
        cfcl = [];
        cfdet = [];
        Texpl = [];
        Dpol = [];
        Taypol = [];
        return
    else
        errfl = 0;
    end
else
    if nW == 0
        error('No solutions.')
    elseif nW > 1
        error('More than one candidate solution. Code not set up for this.')
    end
end


%% Get Taylor coefficients

% Arrays for derivatives and Taylor coefficients (Taylor = deriv/k!, where
% k is order of derivative)
Dpol = zeros(OP.ntrm,OP.npol);     % array for derivatives
Taypol = zeros(OP.ntrm,OP.npol);   % array for Taylor coefficients

% load in first-order derivatives/Taylor coefficients
Dpol(1:OP.nSt0,:) = Dpol1;
Taypol(1:OP.nSt0,:) = Dpol1;

ctr0 = OP.nSt;	% initialize counter to track what row of Dpol we're currently at

for j = 2:OP.ord    % for each order j>1
    % call function to get matrices that are used to compute j-th-order
    % derivatives from lower-order ones
    [AA,BB] = feval(OP.fnDerv{j-1},Dpol(1:ctr0,:),prs,argSS,DQ);
    
    Dj = AA\BB;     % compute j-th-order derivatives
    
    nnewtrm = numel(Dj)/OP.npol;   % number of new derivatives
    ctr1 = ctr0 + nnewtrm;          % counter value at end of this iteration
    
    % load new derivatives/Taylor coefficients into Dpol/Taypol
    Dpol(ctr0+1:ctr1,:) = reshape(Dj,nnewtrm,OP.npol);
    Taypol(ctr0+1:ctr1,:) = Dpol(ctr0+1:ctr1,:)/factorial(j);
    
    ctr0 = ctr1;      % update counter
end

% for collapsed solution:
Taypolcl = OP.cl*Taypol;	% get collapsed Taylor coefficients
cfcl = Taypolcl(OP.tmapcl,:);   % convert to tensor format

% for "deterministic" solution:
Taypoldet = OP.cldet*Taypolcl;  % get "deterministic" Taylor coefficients
cfdet = Taypoldet(OP.tmapdet,:);    % convert to tensor format

%% Check for explosion

if exchk
    % Simulation Tchk periods with "deterministic" coefficients
    [~,~,~,Texpl] = fn_BGPEx_XYESim(cfdet,OP.Tchk,OP.yL0,OP.ebd,argSS,p,OP);
else
    Texpl = [];
end
