function e = fn_BGPEx_e(s,p,cfcl,ord)
%
% This function computes the Taylor approximation for the level of e
% 
% Inputs:
%   s           matrix of different state vectors to compute e for
%   p           struct variable of parameters
%   cfcl        Taylor coefficients from "collapsed" solution
%   ord         order of Taylor approximation
%
% Outputs:
%   e           vector of approximated e's
%
% Note: the following functions must be in the same directory in order to
% run this script (see CodeDescription.pdf for descriptions):
%
%   - TaylSim_tX.m
%
% Outputs:
%   errvc       J-by-1 vector of Euler errors
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%% Initialize

ns = size(s,2);    % number of different state vectors passed in
nvr = size(s,1);    % number of state variables

con = true; % flag to get constant term in Taylor simulations
nord = ord+1;    % total number of Taylro orders (incl. constant

ie=3;   % index associated with e policy function
ce = cfcl(:,ie); % coefficients for e policy function

% steady state and transformed steady state
e_ = p.e_;
te_ = -log(1/e_ - 1);

%% Compute e

ntXk = nvr.^(0:ord);  % vector of number of tensor product terms of each order
tind = [0,cumsum(ntXk)];    % vector of total number of tensor product terms up to each order
nc = sum(ntXk);             % total number of tensor product terms
e = zeros(1,ns);    % allocate memory

for i = 1:ns      % for each state vector
    
    si = s(:,i);    % extract i-th endogenous state vector
    tX = TaylSim_tX(si,tind,nc,con,nord);  % tensor products of current state variables
    eld = ce.'*tX;     % solution for (transformed) e
    e(i) = 1./(exp(-(eld + te_))+1);    % de-transform
end


