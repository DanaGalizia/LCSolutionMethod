function spece = fn_BGPEx_SpecSim(prs,cfcl,OP,epsim,Spec)
%
% This function gets the spectrum of e for the model using a simulation
% approach.
% 
% Inputs:
%   prs         vector of parameter values
%   cfcl        Taylor coefficients from "collapsed" solution
%   OP          struct containing other model variables
%   epsim       draw of exogenous process innovations
%   Spec        struct containing parameters relevant to computing spectrum
%
% Outputs:
%   spece       spectrum of e
%
% Note: the following functions must be in the same directory in order to
% run this script (see CodeDescription.pdf for descriptions):
%
%   - fn_BGPEx_prsStr.m
%   - fn_BGPEx_SS.m
%   - fn_BGPEx_thsim.m
%   - fn_BGPEx_XYESim.m
%   - TaylSim_tX.m
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%% Get spectrum

rho = prs(OP.irho); % autocorrelations
sig = prs(OP.isig); % s.d.'s of innovations

% simulate exogenous variables
thsim = fn_BGPEx_thsim(epsim,OP.th0nrm./sqrt(1-rho.^2),rho,sig);
Tchk = size(thsim,2);

argSS = fn_BGPEx_SS(prs);           % steady state
p = fn_BGPEx_prsStr(prs,'VtoS');    % convert parameters from vector to struct

% simulate data
[~,~,esim,Texpl] = fn_BGPEx_XYESim(cfcl,thsim,OP.yL0,OP.ebd,argSS,p,OP);

if Texpl < Tchk     % check whether simulation exploded
    error('Simulation exploded')    % if so, error out
    
else                % otherwise
    
    % take logs and de-mean
    esim = log(reshape(esim,Spec.Tl,OP.nsmp));  
    esim = esim-mean(esim,1);
    
    % compute spectrum
    pfflp = abs(fft(esim,Spec.TT)).^2;    % un-scaled two-sided spectrum
    speceall = pfflp(1:Spec.TT2,:)/(2*pi*Spec.Tl);     % scaled one-sided spectrum
    spece = mean(speceall,2);     % mean of simulated one-sided spectra
    conspece = [spece(Spec.nkr:-1:2);spece;spece(end-1:-1:end-Spec.nkr+1)]; % extend for wrap-around kernel-smoothing
    conspece = conv(conspece,Spec.kr,'same');       % kernel-smooth
    spece = conspece(Spec.nkr:Spec.TT2+Spec.nkr-1);     % drop extra frequencies added for wrap-around
end


