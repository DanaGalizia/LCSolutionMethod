function [expns,expnscl,tmapcl,cl,expnsdet,tmapdet,cldet] = TaylMaps(ord,ny,nt)
%
% [expns,expnscl,tmapcl,cl,expnsdet,tmapdet,cldet] = TaylMaps(ord,nSt,nSt0)
%
% Obtain various useful mappings for simulating models solved with
% perturbation methods. Specifically, function outputs mappings that can be
% used to convert Taylor approximations of stochastic systems with a
% perturbation parameter into:
%
%   (1) A "collapsed" approximation where the perturbation parameter is 
%       subsumed into the Taylor coefficients themselves (e.g., if we have 
%       Taylor terms a*y and b*y*p, where y is a true state variable and p 
%       is the perturbation parameter that is always set to 1 in practice, 
%       then we can set p=1 and combine these terms to get (a+b)*y); and
%
%   (2) A "deterministic" version where terms involving the stochastic
%       variables are all eliminated. Note that this does not give a
%       perturbation approximation of the solution to the deterministic
%       version of the model. Rather, it provides a representation of the
%       solution to the stochastic model when all stochastic processes
%       have realized values of zero at every date.
%
% NOTE: function assumes:
%
%   (1) The original Taylor approximation has no constant terms (i.e., 
%       expansion is around a non-stochastic steady state of zero), and
%
%   (2) The perturbation parameter is normalized to 1 in simulations
%       (rather than, say, the standard deviation of one of the shocks).
%
% Inputs:
%   ord:    order of the Taylor expansion.
%   ny:     number of endogenous state variables
%   nt:     number of exogenous state variables
%
% Outputs:
%   expns:    matrix each row of which represents a different monomial in the
%             baseline Taylor expansion, with each element in a row giving the
%             exponent on a different state variable (see TaylExp.m)
%   expnscl:  same as expns, but for the "collapsed" Taylor expansion
%   tmapcl:   mapping from monomials in expnscl to their locations in a
%             tensor product of state variables (see TaylExp.m)
%   cl:       matrix that, when pre-multiplying the baseline Taylor
%             expansion, converts it to the "collapsed" one
%   expnsdet: same as expns, but for the "deterministic" Taylor expansion
%   tmapdet:  same as expnscl but for the "deterministic" Taylor expansion
%   cldet:    matrix that, when pre-multiplying the "collapsed" Taylor
%             expansion, converts it to the "determinstic" one

% Written by:
%       Dana Galizia
%       Carleton University
%       Last edit: July 16, 2020

%%

nSt0 = ny+nt;   % total number of state variables (excl. pert. param.)
nSt = nSt0 + 1;   % total number of state variables (incl. pert. param.)


% Matrix 'expns' represents monomials in a 'ord'-th-order multivariate
% polynomial in the state variables (incl. perturb. param.). Each row of
% 'expns' is of the form [n1,...,n5], representing the exponents on the
% state variables. 'tmap' gives indices of monomials corresponding to each
% element of the vectorized tensor product of the state variables.
[expns,~,~] = TaylExp(nSt,ord);    % call function

ntrm = size(expns,1);   % number of monomials in the expansion

%% Mappings from coefficients in full state (including perturb. param.) to
 % state without perturb. param.
 
% Since the perturbation param. is constant over time, we can save on
% computational time when simulating by dropping it as a state variable and
% subsuming it into the coefficient on monomials in the remaining state
% variables. This section computes a matrix 'cl' that, when pre-multiplying
% the full vector of solution coefficients, returns this "collapsed"
% solution.

[expnscl,~,tmapcl] = TaylExp(nSt0,ord,true);	% call TaylExp function again, but
                                            % excluding 1 state variable, and including
                                            % a constant term now
                                            
ntrmcl = size(expnscl,1);   % nubmer of monomials in the collapsed expansion

% The (j,k)-th element of cl is a 1 if the k-th row of expns and the j-th
% row of expnscl imply the same exponents on the "true" state variables.
% The following block constructs this matrix.
cl= zeros(ntrmcl,ntrm);
for j = 1:ntrmcl
    cl(j,:) = ismember(expns(:,1:nSt0),expnscl(j,:),'rows')';
end

%% Mappings from coefficients in collapsed state to endogenous state only
 
% When checking for explosions, we will simulate the model with zeros fed
% in for the shocks. To save on computation time, we simply drop any Taylor
% terms involving exog. states, leaving a "deterministic" solution (though
% agents in the  model continue to believe the model is stochastic). This
% section computes a matrix 'cldet' that, when pre-multiplying the
% vector of "collapsed" solution coefficients, returns this "deterministic"
% solution.

[expnsdet,~,tmapdet] = TaylExp(ny,ord,true); % call TaylExp again, but for
                                                % only the endogenous state variables, 
                                                % and including a constant term

ntrmdet = size(expnsdet,1);     % number of monomials in "deterministic" expansion

% pad exponents with 0s to correspond to exog. state variables
expnsdet = [expnsdet,zeros(ntrmdet,nt)]; 

% The (j,k)-th element of cldet is a 1 if the k-th row of expnscl and the
% j-th row of expnsdet imply the same exponents on all "true" state
% variables. Note that the exponents on exog. state variables are always
% zero in expnsdet. The following block constructs this matrix.
cldet = zeros(ntrmdet,ntrmcl);                                    
for j = 1:ntrmdet
    cldet(j,:) = ismember(expnscl,expnsdet(j,:),'rows')';
end
