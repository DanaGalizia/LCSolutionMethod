function [expns,cmbs,tmap] = TaylExp(N,ord,con)
%
%   [expns,cmbs,tmap] = TaylExp(N,ord,[con])
%
% This function returns a matrix 'expns' representing the monomials in a
% 'ord'-th-order multivariate polynomial in 'N' variables. Each row of
% 'expns' is of the form [n1,...,nN], and represents the monomial
%
%       x1^n1 * x2^n2 * ... * xN^nN
%
% The number of times each monomial appears in a Taylor expansion is given
% in the vector 'cmbs' (e.g., in a second-order Taylor expansion, x1*x2
% appears as d(df/dx1)/dx2 and d(df/dx2)/dx1, while x1^2 only appears once
% as d(df/dx1)/dx1).
% 
% Finally, let x = [x1;...;xN], tens_1 = x, and tens_k be obtained
% recursively as tens_k = kron(tens_(k-1),x). Then each element of tens_k
% is a k-th-order monomial in x1,...,xN (where some monomials appear
% multiple times). Stack these in tens = [tens_1;tens_2;...;tens_ord]. The
% j-th element of the vector 'tmap' gives the row index of the monomial in
% expns corresponding to the j-th element of tens.
%
% Note: Optional argument 'con' = true if we should also include a constant
% term (default = false).
%
% Written by: Dana Galizia, Carleton University
% Last edit: 2019-06-11

%%  Check whether to include constant

if ~exist('con','var')
  con = false;
end

if con      % if including constant
    ford = 0;       % set first order to 0 (constant term)
    nord = ord+1;   % set total number of orders to ord+1
else        % otherwise
    ford = 1;       % set first order to 1
    nord = ord;     % set total number of orders to ord
end

%% Get vector of primes

% Here, one prime number is associated with each state variable. For any two numbers
% x1 and x2 obtained as products of k1 and k2 of these primes (using the same prime more
% than once is allowed), respectively, x1 = x2 if and only if they have the same set of
% prime factors with the same multiplicities, i.e., if and only if they are associated
% with the same monomial.

prmx = (1+N)^2;         % initial upper bound to find all primes less than
suffprm = false;        % flag to indicate that we've found enough primes

while ~suffprm          % if we haven't found enough primes yet
    prms = primes(prmx)';	% generate vector of prime #'s <= prmx
    if numel(prms) >= N     % check if we have enough (one for each state variable)
        suffprm = true;     	% if so exit the while loop
    else                    % otherwise
        prmx = 2*prmx;      	% double upper bound and try again
    end
end

prms = prms(1:N);       % take only the first N primes

%% Tensor products

ntensk = N.^(ford:ord);     % vector of number of terms in each order tensor product
ntens = sum(ntensk);        % total number of terms
tind = [0,cumsum(ntensk)];  % vector of start/end indices for each order tensor

% Here we generate the vector 'tens' of tensor products of the primes. Also
% produce a cell array whose j-th entry is the j-th-order tensor products.
tens = zeros(ntens,1);
tensk = cell(nord,1);
if con          % if including constant term
    tensk{1} = 1;       % first tensor is 0-order term
else            % otherwise
    tensk{1} = prms;    % first tensor is first-order terms
end
tens(tind(1)+1:tind(2)) = tensk{1};
for j = 2:nord
    tensk{j} = kron(tensk{j-1},prms);
    tens(tind(j)+1:tind(j+1)) = tensk{j};
end

%% Construct outputs

% Find first appearance of each unique element of tens (i.e., of each
% unique monomial). Also return mapping tmap such that tens =
% unqtens(tmap), which is the desired output.
[unqtens,~,tmap] = unique(tens,'stable');

nunq = numel(unqtens);       % number of unique elements

% allocate memory for outputs
expns = zeros(nunq,N);
cmbs = zeros(nunq,1);

for j = 1:nunq              % for each unique element (monomial) in tens
    
    mj = unqtens(j);                % unqie element # j
    prmfct = factor(mj);            % prime factorization of mj
    
    for k = 1:N                     % for each prime factor (state variable)
        expns(j,k) = nnz(prmfct==prms(k));	% compute its multiplicity in the factorization
                                            	% and load into expns
    end
    
    ordj = numel(mj);               % order of monomial
    
    % Number of times mj appears in tens is the number of times the
    % corresponding monomial appears in a Taylor expansion. Since mj only
    % appears in ordj-th-order tensor products, we can just check those
    % elements of tens (more efficient).
    cmbs(j) = nnz(tensk{ordj}==unqtens(j));	
end








