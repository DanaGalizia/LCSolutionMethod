% This file contains code to solve the model in Section 5 of Galizia,
% "Solving Rational Expectations Models Featuring Limit Cycles (or 
% Chaos) Using Perturbation Methods" using the perturbation method. This
% code also produces all relevant figures in that section.
%
% Note: the following functions must be in the same directory in order to
% run this script (see CodeDescription.pdf for descriptions):
%
%   - fn_BGPEx_e.m
%   - fn_BGPEx_EulErr.m
%   - fn_BGPEx_prsStr.m
%   - fn_BGPEx_Sol.m
%   - fn_BGPEx_SpecSim.m
%   - fn_BGPEx_SS.m
%   - fn_BGPEx_thsim.m
%   - fn_BGPEx_XYESim.m
%   - fn_BGPExDerv_ord2.m and fn_BGPExDerv_ord3.m
%   - fn_BGPEx_QDerv_ord3.m
%   - fn_BGPEx_FirstOrderMat.m
%   - InvSubGen.m
%   - TaylExp.m
%   - TaylMaps.m
%   - TaylSim_tX.m
%   - rgb.m
%
% Required data files:
%   - pars_mu.mat, pars_z.mat
%   - Spec.mat
%   - EE_FE.mat

%%

clearvars



%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%   INPUTS
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Parameter and simulation options

pfile = 'pars_mu'; % file name containing parameter values (pars_mu for
                    % mu-shock model, pars_z for z-shock model)


Tchk = 1000;    % periods to simulate to check for explosion
Terg = 10000;  % periods to simulate to get ergodic statistics (10000 in paper)
Tbrn = 10000;    % periods to burn in for ergodic statistics (10000 in paper)
nsmp = 500;     % nubmer of simulated samples of same size as actual data

Tpl = 270;      % number of simulation periods for plots


% Initial endogenous states (X,Y) for non-stochastic simulations 
%           X       Y
yL0NSS = [  ...
            7.5,  0.96    ;    % 1st initial state (mu-shock model)
            7.45,  0.94    ;   % 2nd initial state (mu-shock model)
%             7.56,  0.96    ;    % 1st initial state (z-shock model)
%             7.48,  0.94    ;    % 2nd initial state (z-shock model)
        ].';


% Bounds for e that define explosiveness
ebd = [.2;.9999];

nerr = 200;         % number of points to compute Euler errors at
nsim = 15000;    % number of simulations for each Euler error (15000 in paper)
dffct = 0.13;       % factor to control bounds of state variables to compute
                    % Euler errors at

%% Plotting options

svfg = 0;                   % 1 = save figures
ffign = 1;                  % first figure number to use
fsz = 20;                   % font size for axis/legend
lnwd = 4;                   % line width for plots
figpos = .8*[0 0 1058 817]; % figure position








%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%   COMPUTATION
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%% Parameter set-up


[~,pnms] = fn_BGPEx_prsStr([],'nms'); % get list of parameter names

load(pfile) % load file with struct variable containing parameters

prs = fn_BGPEx_prsStr(p,'StoV'); % convert parameter struct to vector

%% Initial set-up 

% seed random number generator (for consistency across runs)
sd = 1546034613;
rng(sd)

ny = 2;     % number of endogenous pre-determined variables
nz = 4;     % number of jump variables
nt = 2;     % number of exogenous stochastic variables
ord = 3;	% perturbation order

nSt0 = ny+nt;   % total number of state variables (excl. pert. param.)
nSt = nSt0 + 1; % total number of state variables (incl. pert. param.)
npol = ny+nz;   % total number of policy functions

% create cell array of handles to functions that compute non-linear Taylor
% coefficients
fnDerv = {@fn_BGPExDerv_ord2; @fn_BGPExDerv_ord3};
fnDQ = @fn_BGPEx_QDerv_ord3;
fnEE = @fn_BGPEx_EulErr;

fign = ffign;       % initialize figure counter

% get useful mappings for Taylor approximations
[expns,expnscl,tmapcl,cl,expnsdet,tmapdet,cldet] = TaylMaps(ord,ny,nt);

ntrm = size(expns,1); % number of monomials in desired Taylor approximation

% index of e_ in pnms
ie_ = find(strcmp(pnms,'e_'));

% steady state values
argSS = fn_BGPEx_SS(prs);   % call function to get SS vector
y_ = argSS(1:2);            % SS for pre-determined variables
X_ = y_(1);                 % SS X
Y_ = y_(2);                 % SS Y

yL0 = [X_;Y_]*.999; % initial endogenous states (X,Y) for simulating to
                        % check for explosion
y0 = log(yL0./y_);  % in log differences

%% START UP THE PARALLEL POOL (IF IT EXISTS).

v = ver;
parexst = any(strcmp({v.Name}, 'Parallel Computing Toolbox'));
if parexst
    pool = gcp('nocreate');
    if isempty(pool)
        pool = parpool();
    end
end

%% Load in data moments

load Spec

%% Stochastic processes

T = Spec.Tl*nsmp;            % total number of periods to simulate
epsim = randn(nt,T);    % draw innovations
th0nrm = randn(nt,1);   % draw initial random stochastic vector (normalized)

irho = [find(strcmp(pnms,'rhoz')); find(strcmp(pnms,'rhomu'))];
isig = [find(strcmp(pnms,'sigz')); find(strcmp(pnms,'sigmu'))];

rho = prs(irho); % autocorrelations
sig = prs(isig); % s.d.'s of innovations

%% Construct struct variable to hold variables needed for solution

OP.ny=ny; OP.npol=npol;OP.ord=ord; OP.ntrm=ntrm;   OP.fnDerv=fnDerv; OP.fnDQ=fnDQ;
OP.nSt0=nSt0; OP.nSt=nSt;     OP.cl=cl;   OP.expnscl=expnscl; OP.tmapcl=tmapcl;
OP.cldet=cldet; OP.expnsdet=expnsdet;   OP.tmapdet=tmapdet;
OP.Tchk=Tchk; OP.yL0=yL0;   OP.ebd=ebd; OP.nsmp = nsmp; OP.ie_ = ie_;

OP.Xp=1; OP.Yp=2; OP.e=3; OP.lm=4; OP.Om=5; OP.io=6;
OP.th0nrm = th0nrm;
OP.irho = irho;
OP.isig = isig;
OP.iphi0 = find(strcmp(pnms,'phi0'));

%% Solve model

[cfcl,cfdet,Texpl,Dpol,Taypol] = fn_BGPEx_Sol(prs,OP); 

spece = fn_BGPEx_SpecSim(prs,cfcl,OP,epsim,Spec); % spectrum for model

%% Display parameters

np = size(pnms,1);
dspcl = cell(np,2);
for j=1:np
    prj = pnms{j};
    if strcmp(prj,'Phi2')
        prj = 'Phitl2';
        prvlj = p.Phi2/(2*100^2*p.Phi0);
    elseif strcmp(prj,'Phi3')
        prj = 'Phitl3';
        prvlj = p.Phi3/(6*100^3*p.Phi0);
    else
        prvlj = p.(prj);
    end
    dspcl{j,1} = prj;
    dspcl{j,2} = prvlj;
end
disp(dspcl)


%% Find limit cycle

NLCbrn = 1500;  % period after which system assumed to have converged to LC
NLC = 1000;     % number of periods of LC to simulate

% simulate
[XLsim,YLsim,~,~] = fn_BGPEx_XYESim(cfdet,NLCbrn+NLC,OP.yL0,OP.ebd,argSS,p,OP);

% drop burn-in period from simulation
XLsim = XLsim(1,NLCbrn+1:end);
YLsim = YLsim(1,NLCbrn+1:end);


% This block converts the simulated deterministic limit cycle into polar
% coordinates (relative to the "center" of the cycle), sorts the result by
% angle, then converts back into Cartesian coordinates.
Xcent = .5*(min(XLsim)+max(XLsim));
Ycent = .5*(min(YLsim)+max(YLsim));
[TH,R] = cart2pol(XLsim-Xcent,YLsim-Ycent);
[srtTH,srti] = sort(TH);
srtR = R(srti);
[srtXL,srtYL] = pol2cart(srtTH,srtR);
XLC = Xcent+srtXL;
YLC = Ycent+srtYL;
XLC = [XLC,XLC(1)];
YLC = [YLC,YLC(1)];

% This block determines ranges of values for state variables including span
% of LC, plus a little bit.
XLCdf = max(XLC)-min(XLC);
YLCdf = max(YLC)-min(YLC);
Xrg = [min(XLC)-dffct*XLCdf,max(XLC)+dffct*XLCdf];
Yrg = [min(YLC)-dffct*YLCdf,max(YLC)+dffct*YLCdf];

%% Non-stochastic simulations

nNSS = size(yL0NSS,2);  % number of non-stochastic simulations

% simulate
XLsimNSS = zeros(1,Tpl+1,nNSS);
YLsimNSS = zeros(1,Tpl+1,nNSS);
eLsimNSS = zeros(1,Tpl,nNSS);
for j = 1:nNSS
    [XLsimNSS(:,:,j),YLsimNSS(:,:,j),eLsimNSS(:,:,j),~] = fn_BGPEx_XYESim(cfdet,Tpl,...
        yL0NSS(:,j),OP.ebd,argSS,p,OP);
end

XLsimNSS = squeeze(XLsimNSS).';
YLsimNSS = squeeze(YLsimNSS).';
eLsimNSS = squeeze(eLsimNSS).';


%% Stochastic simulation

% seed random number generator for consistency
sd = 1546032;
rng(sd)

th0simnrm = randn(nt,1)./sqrt(1-rho.^2); % initial exogenous state

% simulate exogenous variables
thsim = fn_BGPEx_thsim(randn(nt,Tpl),th0simnrm,rho,sig);

% simulate endogenous variables
[XLsimSS,YLsimSS,eLsimSS,~] = fn_BGPEx_XYESim(cfcl,thsim,OP.yL0,OP.ebd,argSS,p,OP);
XLsimSS = XLsimSS.';
YLsimSS = YLsimSS.';
eLsimSS = eLsimSS.';

%% Transversal cuts of Euler errors and policy functions

% values of state variables to get errors at
XLvc = linspace(Xrg(1),Xrg(2),nerr);
YLvc = linspace(Yrg(1),Yrg(2),nerr);

% convert to log-deviations from SS
Xhld = X_;
Yhld = Y_;
yLvc = [XLvc,Xhld*ones(1,nerr);Yhld*ones(1,nerr),YLvc];
yvc = log(yLvc./[X_;Y_]);

tvc = zeros(2,2*nerr);  % set current exogenous states to 0
epsimEE = randn(nt,nsim);    % draw innovations for Monte Carlo Euler error

% call function to compute Euler errors
errvc = fn_BGPEx_EulErr(yvc,tvc,epsimEE,prs,cfcl,OP);

% separate X and Y transversal cuts of Euler errors
errvcX = errvc(1:nerr);
errvcY = errvc(nerr+1:end);

% get policy functions for transversal cuts
spolfn = [yvc;zeros(2,2*nerr)];
epolfn = fn_BGPEx_e(spolfn,p,cfcl,ord);

% separate X and Y transversal cuts of policy functions
epolX = epolfn(1:nerr);
epolY = epolfn(nerr+1:end);

%% Ergodic Euler error distribution

% simulate exogenous variables
therg = fn_BGPEx_thsim(randn(nt,Terg+Tbrn),OP.th0nrm./sqrt(1-rho.^2),rho,sig);

% simulate endogenous variables
[XLerg,YLerg,eLerg,Texplerg] = fn_BGPEx_XYESim(cfcl,therg,OP.yL0,OP.ebd,argSS,p,OP);

% check to make sure the simluation didn't explode
if Texplerg < Terg+Tbrn
    error(['Explosion at period ' num2str(Texplerg)])
end

% drop burn-in period
XLerg = XLerg(1,Tbrn+1:end-1).';
YLerg = YLerg(1,Tbrn+1:end-1).';
eLerg = eLerg(1,Tbrn+1:end).';

% express in log-deviations from SS
yerg = log([XLerg.';YLerg.']./[X_;Y_]);

% call function to compute errors
errerg = fn_BGPEx_EulErr(yerg,therg(:,Tbrn+1:end),epsimEE,prs,cfcl,OP); 

% convert absolute errors to base-10 log
hdat = log10(abs(errerg));

krrg = [prctile(hdat,0.1),max(hdat)+.15];   % range of distribution to plot
krpts = linspace(krrg(1),krrg(2));  % values to get kernel density estimates at
bwth = 0.15;    % kernel bandwidth
krdstEE = fitdist(hdat.','kernel','Width',bwth); % kernel density
pdfvl = pdf(krdstEE,krpts); % pdf of kernel density
cdfvl = cdf(krdstEE,krpts); % cdf of kernel density









%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%   PLOTS
%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%% Plot hours spectrum

% spectrum plot parameters
datclr = rgb('black');
modclr = rgb('dimgray');
bcclr1 = rgb('whitesmoke');
bcclr2 = rgb('gainsboro');
tkclr = rgb('dimgray');
frmn = 1/60;        % lowest frequency to plot
frmx = 1/4;         % highest frequency to plot

freqs = Spec.freqs; % vector of frequencies spectrum is computed at
spcpl = (freqs>=frmn) & (freqs<=frmx);  % indices of frequencies to target in estimation

% determine y-axis limits
alldat = [spece(spcpl);Spec.datspecl(spcpl)];
ydiff = max(alldat);             % maximum plot value
ymx = max(alldat)+ydiff*.05;     % y-axis maximum
ymn = 0;                         % y-axis minimum
yl = [ymn,ymx];

% initialize figure and advance figure counter
figure(fign)
fign = fign + 1;
clf
set(gcf, 'Position', figpos)
hold on

% set up x-axis labels and limits for spectrum plots
xtickper = [2, 4, 6, 24, 32, 40, 50, 60, 80, 128];      % vector of xtick mark locations
ntick = numel(xtickper);                                % number of xtick marks
xticklab = cell(1,ntick);                               % cell to hold xtick labels
for j = 1:ntick                                         % for each tick location
    xticklab{j} = num2str(xtickper(j),'%i');            % label = string value of xtick mark
end
xtickvec = log(xtickper);                               % get logs of tick marks
tkind = find((1./xtickper>frmn)&(1./xtickper<frmx));    % indices of tick marks that will show up in figure
xax = log(min(1./freqs,realmax));                       % get log of periodicities associated with frequencies
xl = [frmn,frmx];                                       % min and max of x-axis in frequencies
xl = log(1./min(xl([2,1]),realmax));                    % min and max of x-axis in log of periodicity


% plot data and model spectra
h1=plot(xax,Spec.datspecl,'-','LineWidth',lnwd,'Color',datclr);      % data spectrum
h2=plot(xax,spece,'-','LineWidth',lnwd/2,'Color',modclr);    % model spectrum

% lines at x-axis tick marks
for j = tkind
    line([xtickvec(j),xtickvec(j)],yl,'Color',tkclr,'LineWidth',0.5,'LineStyle','--')
end
handv1 = get(gca,'Children');

% area plot to shade business cycle regions
a1 = area(([log(6),log(32)]),.995*[ymx, ymx], 'facecolor',bcclr1, 'edgecolor',bcclr1);
a2 = area(([log(32),log(50)]) ,.995*[ymx, ymx], 'facecolor',bcclr2, 'edgecolor',bcclr2);
set(gca,'Layer','top')
handv = [handv1;a1;a2];
set(gca,'Children',handv)

% axis properties
xlabel('Periodicity','FontName','Times','FontSize',fsz,'Interpreter','latex')
xlim(xl)
ylim([ymn,ymx])
set(gca,'XTick',xtickvec,'XTickLabel',xticklab,'FontName','Times','FontSize',fsz,'box','on')

% legend
hleg = legend([h1,h2],{'Data','Model'},'Location','NorthWest');
set(hleg,'FontName','Times','FontSize',fsz)

if svfg == 1
    flnm = [pfile '_spec.pdf'];
    export_fig(flnm, '-transparent')
end

% title
title('Hours Spectrum')

%% Plot simulations in y(t)-space

figure(fign)                    % open next figure
fign = fign + 1;                % advance figure counter
clf                             % clear figure
set(gcf, 'Position', figpos)	% set location and size
hold on                         % turn axis hold on

TplNSS = [95,30];
% plot non-stochastic simulations
j = 1;
plot(XLsimNSS(j,1:TplNSS(j)),YLsimNSS(j,1:TplNSS(j)),':','LineWidth',lnwd,'Color','k');      % #1
j = 2;
plot(XLsimNSS(j,1:TplNSS(j)),YLsimNSS(j,1:TplNSS(j)),'--','LineWidth',lnwd,'Color','k'); % #2

% % plot limit cycle
hLC = plot(XLC,YLC,'-','LineWidth',lnwd+2,'Color','k');

dfct = .1;
xall = [XLsimNSS(:);XLC(:)];
yall = [YLsimNSS(:);YLC(:)];
xmn = min(xall);
xmx = max(xall);
xdff = xmx-xmn;
ymn = min(yall);
ymx = max(yall);
ydff = ymx-ymn;
xl = [xmn-dfct*xdff,xmx+dfct*xdff];
yl = [ymn-dfct*ydff,ymx+dfct*ydff];
xlim(xl)
ylim(yl)

% labels
xlabel('$X$','FontName','Times','FontSize',fsz,'Interpreter','latex')
ylabel('$Y$','FontName','Times','FontSize',fsz,'Interpreter','latex')
text(yL0NSS(1,1)-.0015,yL0NSS(2,1),'$\bullet$','FontName','Times','FontSize',fsz+4,'Interpreter','latex')
text(yL0NSS(1,2)-.0015,yL0NSS(2,2),'$\bullet$','FontName','Times','FontSize',fsz+4,'Interpreter','latex')
text(yL0NSS(1,1),yL0NSS(2,1)-.002,'$a$','FontName','Times','FontSize',fsz+4,'Interpreter','latex')
text(yL0NSS(1,2)+.002,yL0NSS(2,2)-.001,'$b$','FontName','Times','FontSize',fsz+4,'Interpreter','latex')
text(X_-.002,Y_,'$\star$','FontName','Times','FontSize',fsz+4,'Interpreter','latex')
set(gca,'FontName','Times','FontSize',fsz,'box','on')

if svfg == 1
    flnm = [pfile '_LC.pdf'];
    export_fig(flnm, '-transparent')
end


%% Plot evolution of e_t for non-stochastic simulation #1

figure(fign)                    % open next figure
fign = fign + 1;                % advance figure counter
clf                             % clear figure
set(gcf, 'Position', figpos)	% set location and size
hold on                         % turn axis hold on

plot(0:Tpl-1,eLsimNSS(1,:),'LineWidth',lnwd,'Color','k')    % plot I_t

% control axes
xl = [0,Tpl];
yl = ylim;
line(xl,[0,0],'Color','k')
xlim(xl)
ylim(yl)
xlabel('$t$','FontName','Times','FontSize',fsz,'Interpreter','latex')
set(gca,'FontName','Times','FontSize',fsz,'box','on')

if svfg == 1
    flnm = [pfile '_eNonStoch.pdf'];
    export_fig(flnm, '-transparent')
end

%% Plot evolution of e_t for stochastic simulation

figure(fign)                    % open next figure
fign = fign + 1;                % advance figure counter
clf                             % clear figure
set(gcf, 'Position', figpos)	% set location and size
hold on                         % turn axis hold on

plot(0:Tpl-1,eLsimSS,'LineWidth',lnwd,'Color','k')    % plot I_t

% control axes
xl = [0,Tpl];
yl = ylim;
line(xl,[0,0],'Color','k')
xlim(xl)
ylim(yl)
xlabel('$t$','FontName','Times','FontSize',fsz,'Interpreter','latex')
set(gca,'FontName','Times','FontSize',fsz,'box','on')

if svfg == 1
    flnm = [pfile '_eStoch.pdf'];
    export_fig(flnm, '-transparent')
end

%% Plot Euler errors as function of X

clrEE = true;
EELS = '-';

load EE_FE

figure(fign)                    % open next figure
fign = fign + 1;                % advance figure counter
if clrEE
    clf                             % clear figure
end
set(gcf, 'Position', figpos)	% set location and size
hold on                         % turn axis hold on

lgEEX = log10(abs(errvcX));
h = plot(XLvc,lgEEX,'LineWidth',lnwd,'Color','k','LineStyle',EELS);    % plot errors

% control axes
xl = Xrg;
xlim(xl)
yl = [-10,-3];
xlabel('$X$','FontName','Times','FontSize',fsz,'Interpreter','latex')
ylabel('$|\mathcal{E}|$','FontName','Times','FontSize',fsz,'Interpreter','latex')
set(gca,'FontName','Times','FontSize',fsz,'box','on')

if p.sigmu ~=0
    
    lgEEX_FE = log10(abs(errvcX_FE));
    hFE = plot(XLvc_FE,lgEEX_FE,'LineWidth',lnwd,'Color','k','LineStyle',':');    % plot FE errors
    
    % legend
    hleg = legend([h,hFE],{'Pert.','FE'},'Location','SouthWest'...
        ,'Interpreter','latex','AutoUpdate','off');
    set(hleg,'FontName','Times','FontSize',fsz)
        
end

line(min(XLC)*[1,1],yl,'LineStyle','-','LineWidth',lnwd/2,'Color','k')
line(max(XLC)*[1,1],yl,'LineStyle','-','LineWidth',lnwd/2,'Color','k')
ylim(yl)

h = gca;
h.TickLabelInterpreter = 'latex';
ytck = get(gca,'YTick');
nytck = numel(ytck);
ytcklb = cell(nytck,1);
for j = 1:nytck
    ytcklb{j} = ['$10^{' num2str(ytck(j)) '}$'];
end
set(gca,'YTickLabel',ytcklb)

if svfg == 1
    flnm = [pfile '_EE_X.pdf'];
    export_fig(flnm, '-transparent')
end

%% Plot Euler errors as function of Y

figure(fign)                    % open next figure
fign = fign + 1;                % advance figure counter
if clrEE
    clf                             % clear figure
end
set(gcf, 'Position', figpos)	% set location and size
hold on                         % turn axis hold on

lgEEY = log10(abs(errvcY));
h = plot(YLvc,lgEEY,'LineWidth',lnwd,'Color','k','LineStyle',EELS);    % plot errors

% control axes
xl = Yrg;
yl = [-11,-3];
xlim(xl)
xlabel('$Y$','FontName','Times','FontSize',fsz,'Interpreter','latex')
ylabel('$|\mathcal{E}|$','FontName','Times','FontSize',fsz,'Interpreter','latex')
set(gca,'FontName','Times','FontSize',fsz,'box','on')

if p.sigmu ~=0
    
    lgEEY_FE = log10(abs(errvcY_FE));
    hFE = plot(YLvc_FE,lgEEY_FE,'LineWidth',lnwd,'Color','k','LineStyle',':');    % plot FE errors
    
    % legend
    hleg = legend([h,hFE],{'Pert.','FE'},'Location','SouthWest'...
        ,'Interpreter','latex','AutoUpdate','off');
    set(hleg,'FontName','Times','FontSize',fsz)
    
end

line(min(YLC)*[1,1],yl,'LineStyle','-','LineWidth',lnwd/2,'Color','k')
line(max(YLC)*[1,1],yl,'LineStyle','-','LineWidth',lnwd/2,'Color','k')
ylim(yl)

h = gca;
h.TickLabelInterpreter = 'latex';
ytck = get(gca,'YTick');
nytck = numel(ytck);
ytcklb = cell(nytck,1);
for j = 1:nytck
    ytcklb{j} = ['$10^{' num2str(ytck(j)) '}$'];
end
set(gca,'YTickLabel',ytcklb)

if svfg == 1
    flnm = [pfile '_EE_Y.pdf'];
    export_fig(flnm, '-transparent')
end


%% Plot cdf/pdf of ergodic distribution of Euler errors

figure(fign)                    % open next figure
fign = fign + 1;                % advance figure counter
clf                             % clear figure
set(gcf, 'Position', figpos)	% set location and size
hold on                         % turn axis hold on

xl = krrg;

% plot pdf into left axis
yyaxis left
hpdf = plot(krpts,pdfvl,'LineWidth',lnwd,'Color','k');    % plot pdf
xlim(xl)
set(gca,'FontName','Times','FontSize',fsz,'box','on','YColor', [0.15,0.15,0.15])

% plot cdf into right axis
yyaxis right
hcdf = plot(krpts,cdfvl,':','LineWidth',lnwd,'Color','k');    % plot cdf
xlim(xl)
yl = [0,1];
ylim(yl)
set(gca,'FontName','Times','FontSize',fsz,'box','on','YColor', [0.15,0.15,0.15])

xlabel('$|\mathcal{E}|$','FontName','Times','FontSize',fsz,'Interpreter','latex')

% legend
hl = legend([hpdf,hcdf],{'PDF (left ax.)';'CDF (right ax.)'},'FontName','Times'...
    ,'Location','NorthWest','FontSize',fsz);

h = gca;
h.TickLabelInterpreter = 'latex';
xtck = get(gca,'XTick');
nxtck = numel(xtck);
xtcklb = cell(nxtck,1);
for j = 1:nxtck
    xtcklb{j} = ['$10^{' num2str(xtck(j)) '}$'];
end
set(gca,'XTickLabel',xtcklb)

if svfg == 1
    flnm = [pfile '_EE_Erg.pdf'];
    export_fig(flnm, '-transparent')
end

%% Plot policy function as function of X

figure(fign)                    % open next figure
fign = fign + 1;                % advance figure counter
clf
set(gcf, 'Position', figpos)	% set location and size
hold on                         % turn axis hold on

h = plot(XLvc,epolX,'LineWidth',lnwd,'Color','k','LineStyle','-');
hFE = plot(XLvc_FE,epolX_FE,'LineWidth',lnwd,'Color','k','LineStyle',':');

% control axes
xl = Xrg;
xlim(xl)
yl = [.9,.99];
ylim(yl)
xlabel('$X$','FontName','Times','FontSize',fsz,'Interpreter','latex')
set(gca,'FontName','Times','FontSize',fsz,'box','on')

line(min(XLC)*[1,1],yl,'LineStyle','-','LineWidth',lnwd/2,'Color','k')
line(max(XLC)*[1,1],yl,'LineStyle','-','LineWidth',lnwd/2,'Color','k')

% legend
hleg = legend([h,hFE],{'Pert.','FE'},'Location','NorthEast'...
    ,'Interpreter','latex');
set(hleg,'FontName','Times','FontSize',fsz)

if svfg == 1
    flnm = [pfile '_epolX.pdf'];
    export_fig(flnm, '-transparent')
end


%% Plot policy function as function of Y

figure(fign)                    % open next figure
fign = fign + 1;                % advance figure counter
clf
set(gcf, 'Position', figpos)	% set location and size
hold on                         % turn axis hold on

h = plot(YLvc,epolY,'LineWidth',lnwd,'Color','k','LineStyle','-');
hFE = plot(YLvc_FE,epolY_FE,'LineWidth',lnwd,'Color','k','LineStyle',':');

% control axes
xl = Yrg;
xlim(xl)
yl = ylim;
ylim(yl)
xlabel('$Y$','FontName','Times','FontSize',fsz,'Interpreter','latex')
set(gca,'FontName','Times','FontSize',fsz,'box','on')

line(min(YLC)*[1,1],yl,'LineStyle','-','LineWidth',lnwd/2,'Color','k')
line(max(YLC)*[1,1],yl,'LineStyle','-','LineWidth',lnwd/2,'Color','k')

% legend
hleg = legend([h,hFE],{'Pert.','FE'},'Location','SouthEast'...
    ,'Interpreter','latex');
set(hleg,'FontName','Times','FontSize',fsz)

if svfg == 1
    flnm = [pfile '_epolY.pdf'];
    export_fig(flnm, '-transparent')
end





