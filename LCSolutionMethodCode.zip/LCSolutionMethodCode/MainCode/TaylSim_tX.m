function tX = TaylSim_tX(st,tind,nc,con,nord)
%
% tX = TaylSim_tX(st,tind,nc,con,nord)
%
% Function to compute vector of multivariate Taylor monomials in the
% current state variables.
%
% Inputs:
%   st:     state vector
%   tind:   indices giving locations of monomials for each order in output
%               vector
%   nc:     total number of monomials
%   con:    logical flag = true if including constant term, false otherwise
%   nord:   number of different monomial orders (incl. const. if applic.)
%       functions 'ismembertol' and 'uniquetol' for details
%
% Outputs:
%   tX: vector of monomials
%       is w.r.t. to theta)
%
%
% Written by:
%       Dana Galizia
%       Carleton University
%       Last edit: June 30, 2020

%%

tX = zeros(nc,1);
if con          % if including constant term
    tX(1) = 1;
    j = 2;
    tXk = st;
    tX(tind(j)+1:tind(j+1)) = tXk;
else            % otherwise
    j = 1;
    tXk = st;
    tX(tind(j)+1:tind(j+1)) = tXk;
end

j1 = j+1;
for j = j1:nord
    tXk = kron(tXk,st);
    tX(tind(j)+1:tind(j+1)) = tXk;
end
