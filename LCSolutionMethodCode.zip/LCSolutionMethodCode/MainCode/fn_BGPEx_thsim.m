function thsim = fn_BGPEx_thsim(epsim,st0,rho,sig)
%
% This function simulates stochastic exogenous variables given an initial
% state and a sequence of innovations.
% 
% Inputs:
%   epsim       unscaled innovations (i.e., i.i.d. N(0,1) draws)
%   st0         initial exogenous state
%   rho         vector of autocorrelation parameters
%   sig         vector of s.d.'s of innovations
%
% Outputs:
%   thsim       simulated exogenous variables
%   cfdet       Taylor coefficients from "deterministic" solution
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%%

nser = size(epsim,1);
T = size(epsim,2);
thsim = zeros(nser,T);
for j = 1:nser
    a = [1, -rho(j)];
    thsim(j,:)= filter(1,a,epsim(j,:),rho(j)*st0(j));
end

thsim = sig.*thsim;