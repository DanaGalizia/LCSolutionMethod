function [X,Y,e,Texpl] = fn_BGPEx_XYESim(c,thsim,yL0,ebd,argSS,p,OP)
%
% This function simulates X, Y and e from the model using the perturbation
% approximation.
% 
% Inputs:
%   c           coefficients for perturbation approximation
%   thsim       sequence of exogenous variables; for deterministic
%                   simulations, thsim is the length of simulation (scalar)
%   yL0         initial state
%   ebd         bounds defining whether the solution has exploded
%   argSS       vector of steady state values
%   p           struct containing parameter values
%   OP          struct containing other model variables
%
% Outputs:
%   X           simulation for X
%   Y           simulation for Y
%   e           simulation for e
%   Texpl       period of explosion (if applicable)
%
% Note: the following functions must be in the same directory in order to
% run this script (see CodeDescription.pdf for descriptions):
%
%   - TaylSim_tX.m
%
% For Galizia (2020), “Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods”

%% Initial setup

% check whether simulation is stochastic
exexst = (numel(thsim)>1);

if exexst   % if stochastic
    T = size(thsim,2);  % length of simulation is length of exog. sample
    nSt = numel(yL0) + size(thsim,1); % set number of state variables
else        % if deterministic
    T = thsim;      % length of simulation is just thsim
    nSt = numel(yL0); % set number of state variables
end

ntXk = nSt.^(0:OP.ord);  % vector of number of tensor product terms of each order
tind = [0,cumsum(ntXk)];    % vector of total number of tensor product terms up to each order
nc = sum(ntXk);             % total number of tensor product terms
con = true;         % flag to indicate there's a constant term
nord = OP.ord+1;    % total number of Taylor orders (incl. constant)

ce = c(:,OP.e);     % Taylor coefficients for e policy function

e_ = p.e_;              % steady state e
te_ = -log(1/e_ - 1);   % transformation of steady state e

% extract some parameters from p
al = p.al;
del = p.del;
psi = p.psi;

%% Simulate

% allocate memory
X = zeros(1,T+1);
Y = zeros(1,T+1);
e = zeros(1,T);

y_ = argSS(1:2);    % steady state for endog. state variables

% initial values of state variables
X(1) = yL0(1);
Y(1) = yL0(2);

for t = 1:T      % for each state vector
    yt = log([X(t);Y(t)]./y_);  % log-deviation
    
    % get t-th exogenous vector if applicable
    if exexst
        tht = thsim(:,t);
    else
        tht = [];
    end
    
    st = [yt;tht];           % full state vector at date t
    tX = TaylSim_tX(st,tind,nc,con,nord);  % tensor products of current state variables
    
    etr = ce.'*tX;     % solution for transformed e
    e(t) = 1./(exp(-(etr + te_))+1);    % solution for e
    
    % solution for Y(t+1)
    if exexst
        Y(t+1) = exp(tht(1))*e(t)^al;
    else
        Y(t+1) = e(t)^al;
    end
    
    % solution for X(t+1)
    X(t+1) = (1-del)*X(t) + psi*Y(t+1);

    % check for explosion and exit if there's been one
    if (e(t)<ebd(1)) || (e(t)>ebd(2))
        Texpl = t;
        return;
    end        
end

Texpl = T; % if no explosion, just set Texpl to length of simulation

