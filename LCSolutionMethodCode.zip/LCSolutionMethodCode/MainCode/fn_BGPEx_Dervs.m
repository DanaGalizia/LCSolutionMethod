function fn_BGPEx_Dervs(ord)
%
% This function automatically generates MATLAB functions that will be used
% to iteratively obtain (up to ord-th-order) Taylor approximations to the
% solution functions for the example in Section 5 of Galizia (2020), 
% �Saddle Cycles: Solving Rational Expectations Models Featuring Limit 
% Cycles (or Chaos) Using Perturbation Methods�.
% 
% Inputs:
%   ord         order of approximation
%
% Note: Requires Symbolic Toolbox to run. The following functions must be 
% in the same directory in order to run this script (see
% CodeDescription.pdf for descriptions):
%
%   - fn_BGPEx_prsStr.m
%   - TaylExp.m

%%

codeopt = true;     % true = optimize function code; takes longer, but saves lots of time at function eval


%% THIS BLOCK IS USED TO START UP THE PARALLEL POOL (IF IT EXISTS).

v = ver;
parexst = any(strcmp({v.Name}, 'Parallel Computing Toolbox'));
if parexst
    pool = gcp('nocreate');
    if isempty(pool)
        pool = parpool();
    end
end

tstrt = tic;

%% Initial variable definitions

X = sym('X','real');
Y = sym('Y','real');
e = sym('e','real');
lm = sym('lm','real');
Om = sym('Om','real');
io = sym('io','real');

Xp = sym('Xp','real');
Yp = sym('Yp','real');
ep = sym('ep','real');
lmp = sym('lmp','real');
Omp = sym('Omp','real');
iop = sym('iop','real');

z = sym('z','real');
mu = sym('mu','real');
zp = sym('zp','real');
mup = sym('mup','real');
epz = sym('epz','real');
epmu = sym('epmu','real');

zet = sym('zet','real');

assumeAlso(zet>=0);

% steady state values (Note: These will be in levels, not logs)
X_ = sym('X_','real');
Y_ = sym('Y_','real');
lm_ = sym('lm_','real');
Om_ = sym('Om_','real');
io_ = sym('io_','real');
z_ = 1;
mu_ = 1;
zet_ = 0;

% state vector (including perturbation parameter)
St = [X;Y;z;mu;zet];
nSt = numel(St);        % number of state variables

% Get list of parameters and create associated symbolic variables
[~,pnms] = fn_BGPEx_prsStr([],'nms'); % get list of parameter names
npr = numel(pnms);
prs = sym('prs',[npr,1]);
for j = 1:npr
    eval([pnms{j} ' = sym(''' pnms{j} ''',''real'');'])
    eval(['prs(j) = ' pnms{j} ';'])
end

% Explicitly assign values to parameters below so MATLAB knows they exist
psi = psi;
rhoz = rhoz;
sigz = sigz;
rhomu = rhomu;
sigmu = sigmu;

% parameter assumptions
assumeAlso([del al e_ om gam psi phie phi0 Phi0 rhoz sigz rhomu sigmu]>0);
assumeAlso([del al e_ gam psi phi0 Phi0 rhoz rhomu]<1);

Q_ = e_^(-phie);    % steady state Q

% functions giving next-period exogenous variables
Pi_z = rhoz*z+zet*sigz*epz;
Pi_mu = rhomu*mu+zet*sigmu*epmu;

% Matrix 'expns' represents monomials in a 'ord'-th-order multivariate
% polynomial in the 5 state variables (incl. perturb. param.). Each row of
% 'expns' is of the form [n1,...,n5], representing the exponents on each
% state variable.
[expns,~,~] = TaylExp(nSt,ord);

%% Construct variables for coefficients in Taylor expansion of Q

% The elements of DQ below will show up in the derivatives of the model equations
% as objects that MATLAB interprets as derivatives. We will then replace
% those derivatives with the elements of DGvr, which MATLAB will interpret
% simply as symbolic variables.

Q = symfun('Q(e)',e);

DQ = sym('DQ',[ord,1],'real');    % vector for derivatives of Q (as derivatives)
DQvr = sym('Q',[ord,1],'real');   % vector for derivatives of Q (as variables)

dQ0 = Q;
for j = 1:ord
    dQ0 = diff(dQ0,e);
    DQ(j,:) = dQ0;
end

%% Construct variables for derivatives of policy functions

Psi_X = symfun('Psi_X(X,Y,z,mu,zet)',[X,Y,z,mu,zet]);
Psi_Y = symfun('Psi_Y(X,Y,z,mu,zet)',[X,Y,z,mu,zet]);
eta_e = symfun('eta_e(X,Y,z,mu,zet)',[X,Y,z,mu,zet]);
eta_lm = symfun('eta_lm(X,Y,z,mu,zet)',[X,Y,z,mu,zet]);
eta_Om = symfun('eta_Om(X,Y,z,mu,zet)',[X,Y,z,mu,zet]);
eta_io = symfun('eta_io(X,Y,z,mu,zet)',[X,Y,z,mu,zet]);
pol = [Psi_X,Psi_Y,eta_e,eta_lm,eta_Om,eta_io];
npol = 6;   % number of policy functions

ntrm = size(expns,1);   % number of monomials in n-th order Taylor expansion of policy function

% The elements of Dpol will show up in the derivatives of the model equatio
% equations as objects that MATLAB interprets as derivatives. We will then
% replace those derivatives with the elements of Dpolvr, which MATLAB will
% interpret simply as symbolic variables, which we can then solve for.
Dpol = sym('Dpol',[ntrm,npol],'real');    % matrix to hold symbolic derivatives of policy functions
Dpolvr = sym('Dpolvr',[ntrm,npol],'real');    % matrix of derivative variables for policy functions

% stuff to deal with zeroing out 1st-order derivs w.r.t. perturbation param. (zet)
zet1srch = [0,0,0,0,1];      % exponents in monomial corresponding to those derivatives
zet1ind = ismember(expns,zet1srch,'rows');  % location of that monomial in expns
Dpolvrzet1 = Dpolvr(zet1ind,:);             % derivative variables for those derivatives


inds = cell(ord,1);   % j-th element will hold indices of j-th-order terms in 'expns'

% The variable dffpol will hold the derivatives of the policy functions for
% the previous order
dffpol = sym('dffpol',[1,npol],'real');
dffpol(1,:) = pol;            % initialize dffpol with "zero-order" derivatives

Dpolind = 0;        % variable to track index of last derivative loaded
                    % into Dpol; initialize to 0
for j = 1:ord
    inds{j} = find(sum(expns,2)==j);    % indices of j-th-order terms
    nordj = numel(inds{j});             % number of j-th-order terms
    Dpolj = sym('Dpolj',[nordj,npol]);  % matrix to hold j-th-order derivatives
    expnsj = expns(inds{j},:);          % exponents of j-th-order terms
    
    for k = 1:nordj                     % for each j-th-order term
        
        expnsjk = expnsj(k,:);          % vector of exponents for target term
        
        % To minimize the number of analytic derivatives that need to be
        % taken, for derivatives of order j > 1 we will start from an
        % existing (j-1)-th-order derivative such that we need only
        % differentiate it once with respect to one element of St in order
        % to get the desired j-th-order derivative. In practice, we find a
        % nSt-vector expdff that has m-th element 1 (and 0s elsewhere) if 
        % we can differentiate the (j-1)-th-order derivative w.r.t. the
        % m-th element of St in order to get the desire j-th-order
        % derivative.
        
        if j == 1                   % if this is a first-order term
            
            expdff = expnsjk;           % expnsjk has the desired structure for expdff
            kpind = 1;                  % index of row of dffpol to differentiate (in this case, the only row)
            
        else                        % otherwise if this is a higher-order term
            
            expnsjm1 = expns(inds{j-1},:);  % get matrix of exponents on (j-1)-th-order terms
            
            % create matrix, each of whose rows is the target vector of exponents
            repexpnstjk = repmat(expnsjk,numel(inds{j-1}),1);
            
            % compute differences between current and (j-1)-th-order exponents
            dffexp = repexpnstjk - expnsjm1;
            
            % Find logical indices of (j-1)-th-order terms that have all
            % exponents no greater than target term. Any of these could
            % be differentiated exactly once (w.r.t. one argumet) to get
            % the target term.
            kpind = prod(dffexp >= 0,2);
            
            % Since there are generally multiple, just get the linear index
            % of the first one.
            kpind = find(kpind,1);
            
            % expdff is then just the difference between the exponents of
            % the target term and the exponents of the (j-1)-th-order term
            % we're using.
            expdff = expnsjk - expnsjm1(kpind,:);   
        end

        m = find(expdff);     % indices of non-zero elements of expdff

        % If everything worked properly, there should only be one non-zero
        % element of expdff, and it should equal 1.
        if numel(m)>1 || expdff(m) ~= 1
            error('Something is wrong.')
        end
        
        % compute target derivative and load into k-th element of Dpolj
        Dpolj(k,:) = diff(dffpol(kpind,:),St(m));
        
    end
    
    % After computing all j-th-order derivatives, load them into
    % appropriate sub-vector of Dpol, then update Dpolind
    Dpol(Dpolind+1:Dpolind+nordj,:) = Dpolj;
    Dpolind = Dpolind + nordj;
    
    dffpol = Dpolj;     % update variable holding previous-order derivatives
end

%% Compute moments of N(0,1) RV's

% MGF for normal distribution
y = sym('y','real');
nmgf = symfun(exp(y^2/2),y);

% vector holding moments of eps(t+1)
epmom = sym('Eeps',[ord,1]);
for j = 1:ord
    % j-th derivative of MGF evaluated at zero
    epmom(j) = subs(diff(nmgf,y,j),y,0);
end

%% Set up endogenous model equations and sub in policy functions

c = sym('c','real');
Up = symfun(c^(-om),c);
F = symfun(z*e^al,[e,z]);

bd01 = symfun(-log(1./e-1),e);
bd01Inv = symfun(1./(exp(-e)+1),e);

% Note: We make Q a function of -log(1/e-1) rather than e as in the text. This
% just simplifies the code a bit.
eqend = [	( mu*lm == Q(bd01(e))*Omp );   ...
            ( Xp == (1-del)*X + psi*Yp );	...
            ( Yp == F(e,z) );    ...
            ( lm == Up(io) ); ...
            ( Om == e^phie*lm ); ...
            ( io == Yp + (1-gam/(1-del))*X - (1-psi/(1-del))*gam*Y ); ...
        ];

neqend = numel(eqend);
allvrs = [X,Y,z,mu,lm,Om,io,Xp,Yp,zp,mup,lmp,Omp,iop];
eqend = subs(eqend,allvrs,exp(allvrs));
eqend = subs(eqend,[e,ep],bd01Inv([e,ep]));
eqend = simplify(eqend);

eqend1 = eqend;     % save what's been done so far for later

eqend = subs(eqend,ep,eta_e(Xp,Yp,zp,mup,zet));
eqend = subs(eqend,lmp,eta_lm(Xp,Yp,zp,mup,zet));
eqend = subs(eqend,Omp,eta_Om(Xp,Yp,zp,mup,zet));
eqend = subs(eqend,iop,eta_io(Xp,Yp,zp,mup,zet));
eqend = subs(eqend,Xp,Psi_X(X,Y,z,mu,zet));
eqend = subs(eqend,Yp,Psi_Y(X,Y,z,mu,zet));
eqend = subs(eqend,e,eta_e(X,Y,z,mu,zet));
eqend = subs(eqend,lm,eta_lm(X,Y,z,mu,zet));
eqend = subs(eqend,Om,eta_Om(X,Y,z,mu,zet));
eqend = subs(eqend,io,eta_io(X,Y,z,mu,zet));
eqend = subs(eqend,zp,Pi_z);
eqend = subs(eqend,mup,Pi_mu);

%% Steady state

x = [X;Y;e;lm;Om;io];
xp = [Xp;Yp;ep;lmp;Omp;iop];
t = [z;mu];
tp = [zp;mup];

x_ = [log(X_);log(Y_);bd01(e_);log(lm_);log(Om_);log(io_)];

t_ = log([z_;mu_]);

argSS = [X_;Y_;lm_;Om_;io_];

%% Get first-order matrices Gx0,Gx1,Gt0,Gt1,Bt, where
% Gx0*x + Gx1*E[x']+ Gt0*t + Gt1*E[t'] = 0 , E[t'] = Pi*t

nx = numel(x);
nt = numel(t);

Gx0 = sym('Gx0',[nx,nx]);
Gx1 = sym('Gx1',[nx,nx]);
Gt0 = sym('Gt0',[nx,nt]);
Gt1 = sym('Gt1',[nx,nt]);
Pi = sym('Pi',[nt,nt]);

for j = 1:nx
    deqns = diff(eqend1,x(j));
    deqns = subs(deqns,[xp;tp],[x;t]);
    deqns = subs(deqns,DQ(1),DQvr(1));           % replace Q'
    deqns = subs(deqns,Q,Q_);              % replace Q with SS value
    deqns = subs(deqns,[x;t],[x_;t_]);
    Gx0(:,j) = lhs(deqns)-rhs(deqns);
    
    deqns = diff(eqend1,xp(j));
    deqns = subs(deqns,[xp;tp],[x;t]);
    deqns = subs(deqns,DQ(1),DQvr(1));           % replace Q'
    deqns = subs(deqns,Q,Q_);              % replace Q with SS value
    deqns = subs(deqns,[x;t],[x_;t_]);
    Gx1(:,j) = lhs(deqns)-rhs(deqns);
end

PiCE = [Pi_z;Pi_mu];
PiCE = subs(PiCE,zet,0);

for j = 1:nt
    deqns = diff(eqend1,t(j));
    deqns = subs(deqns,[xp;tp],[xp;tp]);
    deqns = subs(deqns,DQ(1),DQvr(1));           % replace Q'
    deqns = subs(deqns,Q,Q_);              % replace Q with SS value
    deqns = subs(deqns,[x;t],[x_;t_]);
    Gt0(:,j) = lhs(deqns)-rhs(deqns);
    
    deqns = diff(eqend1,tp(j));
    deqns = subs(deqns,[xp;tp],[xp;tp]);
    deqns = subs(deqns,DQ(1),DQvr(1));           % replace Q'
    deqns = subs(deqns,Q,Q_);              % replace Q with SS value
    deqns = subs(deqns,[x;t],[x_;t_]);
    Gt1(:,j) = lhs(deqns)-rhs(deqns);
    
    dPi = diff(PiCE,t(j));
    dPi = subs(dPi,t,t_);
    Pi(:,j) = dPi;
end

flnm = 'fn_BGPEx_FirstOrderMat';   % name of function
    
% create m-function that takes parameters and steady state values
% as inputs and returns A0 and A1
matlabFunction(Gx0,Gx1,Gt0,Gt1,Pi,'File',flnm,'Vars',{prs,argSS,DQvr},...
    'Outputs',{'Gx0','Gx1','Gt0','Gt1','Pi'});

%% Get derivatives evaluated at steady state

Deqend = cell(ord,1);    % j-th element holds matrix of j-th-order derivatives of equations,
                            % where each column of matrix is one of the two equations
tic
disp('Obtaining derivatives')

dffeq = eqend.';
for j = 1:ord
    inds{j} = find(sum(expns,2)==j);    % indices of j-th-order terms
    nordj = numel(inds{j});             % number of j-th-order terms
    Deqendj = sym('Deqendj',[nordj,neqend]); % matrix to hold j-th-order derivatives
    expnsj = expns(inds{j},:);          % exponents of j-th-order terms
    Deqj = sym('Deqj',[nordj,neqend]);
    
    parfor k = 1:nordj                     % for each j-th-order term
        
        expnsjk = expnsj(k,:);          % vector of exponents for this term
        
        % To minimize the number of analytic derivatives that need to be
        % taken, for derivatives of order > 1 we will start from an
        % existing lower-order derivative. To find a suitable lower-order
        % derivative, we construct a variable 'expdff' that holds the 
        % number of additional derivatives that need to be taken starting 
        % from the (j-1)-th-order derivative that is closest to the target
        % j-th-order one with no orders being greater for any variable.
        
        if j == 1                   % if this is a first-order term
            
            expdff = expnsjk;           % expnsjk has the desired structure for expdff
            kpind = 1;                  % index of row of dffeq to differentiate (in this case, the only row)
            
        else                        % otherwise if this is a higher-order term
            
            expnsjm1 = expns(inds{j-1},:);  % get matrix of exponents on (j-1)-th-order terms
            
            % create matrix, each of whose rows is the target vector of exponents
            repexpnstjk = repmat(expnsjk,numel(inds{j-1}),1);
            
            % compute differences between current and (j-1)-th-order exponents
            dffexp = repexpnstjk - expnsjm1;
            
            % Find logical indices of (j-1)-th-order terms that have all
            % exponents no greater than target term. Any of these could
            % be differentiated exactly once (w.r.t. one argumet) to get
            % the target term.
            kpind = prod(dffexp >= 0,2);
            
            % Since there are generally multiple, just get the linear index
            % of the first one.
            kpind = find(kpind,1);
            
            % expdff is then just the difference between the exponents of
            % the target term and the exponents of the (j-1)-th-order term
            % we're using.
            expdff = expnsjk - expnsjm1(kpind,:);   
            
        end
        
        m = find(expdff);     % indices of non-zero elements of expdff

        % If everything worked properly, there should only be one non-zero
        % element of expdff, and it should equal 1.
        if numel(m)>1 || expdff(m) ~= 1
            error('Something is wrong.')
        end
        
        % compute target derivative and load into k-th element of Dpolj
        Deqj(k,:) = diff(dffeq(kpind,:),St(m));   % differentiate (j-1)-th-order equation w.r.t.
                                            % appropriate state variable
        
        % substitute in derivative variables/steady state values
        dffeqsb = Deqj(k,:);
        dffeqsb = subs(dffeqsb,Pi_z,z);      % substitute in current z for future
        dffeqsb = subs(dffeqsb,Pi_mu,mu);      % substitute in current mu for future
        exfl = false;
        % this block keeps making substitutions to replace policy functions
        % with associated variables until there are no more substitutions
        % to make
        while ~exfl
            tmp = dffeqsb;
            tmp = subs(tmp,Dpol,Dpolvr);                        % replace policy-function derivatives
            tmp = subs(tmp,Dpolvrzet1,zeros(1,npol));           % zero first-order terms w.r.t. zet
            tmp = subs(tmp,Psi_X(X, Y, z, mu, zet),X);         % substitute in current X for function
            tmp = subs(tmp,Psi_Y(X, Y, z, mu, zet),Y);         % substitute in current Y for function
            tmp = subs(tmp,eta_e(X, Y, z, mu, zet),e);         % substitute in current e for function
            tmp = subs(tmp,eta_lm(X, Y, z, mu, zet),lm);       % substitute in current lm for function
            tmp = subs(tmp,eta_Om(X, Y, z, mu, zet),Om);       % substitute in current Om for function
            tmp = subs(tmp,eta_io(X, Y, z, mu, zet),io);       % substitute in current io for function
            exfl = ~any(tmp ~= dffeqsb);
            dffeqsb = tmp;
        end
        
        dffeqsb = feval(symengine,'rewrite',dffeqsb,'diff');    % convert 'D' derivative notation to 'diff'
        dffeqsb = subs(dffeqsb,Dpol,Dpolvr);        % replace policy-function derivatives
        dffeqsb = subs(dffeqsb,Dpolvrzet1,zeros(1,npol));   % zero first-order terms w.r.t. zet
        dffeqsb = subs(dffeqsb,DQ,DQvr);           % replace Q derivatives
        
        % other SS values
        dffeqsb = subs(dffeqsb,Q,Q_);
        dffeqsb = subs(dffeqsb,[x;t],[x_;t_]);
        dffeqsb = subs(dffeqsb,zet,zet_);
        
        % Deal with expectations of epz, epmu:
        dffeqsb = expand(dffeqsb);
        for p = j:-1:1      % for each exponent p on ep starting with the highest
            dffeqsb = subs(dffeqsb,[epz^p,epmu^p],[epmom(p),epmom(p)]);     % substitue in value of E[eps(t+1)^p]
        end
        dffeqsb = simplify(dffeqsb);
        
        % load final expression into matrix of j-th-order derivatives
        Deqendj(k,:) = dffeqsb;
    end
    
    % load vector of j-th-order derivatives into j-th element of cell array
    Deqend{j} = Deqendj;
    
    dffeq = Deqj;
end

toc

%% Construct functions to obtain j-th-order derivatives from (j-1)-th- and
%  lower-order derivatives.

Dj = cell(ord,1);
for j = 1:ord
    tmp = Dpolvr(inds{j},:);
    Dj{j} = tmp(:);
end

Djm1 = cell(ord-1,1);
Djm1{1} = Dpolvr(inds{1},:);
for j = 2:ord-1
    Djm1{j} = [Djm1{j-1};Dpolvr(inds{j},:)];
end

for j = 2:ord               % for each order >= 2
    
    % construct matrices AA and BB in expression AA*vec(Dj{j}) = BB that can then be
    % used to solve for vec(Dj{j})
    
    Deqendj = Deqend{j};
    Deqendj = Deqendj(:);
    
    [AA,BB] = equationsToMatrix(Deqendj, Dj{j});
    Djm1j = Djm1{j-1};
    
    % create m-function that takes parameters and lower-order derivatives
    % as inputs and returns AA and BB
    tic
    disp(['Creating order ' num2str(j) ' file'])
    flnm = ['fn_BGPExDerv_ord' num2str(j)];   % name of function
    matlabFunction(AA,BB,'File',flnm,'Vars',{Djm1j,prs,argSS,DQvr},'Outputs',{'AA','BB'},'Optimize',codeopt);
	toc
end

toc(tstrt)

%% Q function

Phi = symfun(Phi0*exp((Phi2/Phi0)*(e-e_)^2/2 + (Phi3/Phi0)*(e-e_)^3/6),e);
betTh = e_^(-phie)/(1+(1-e_)*phi0*Phi0);
Q1 = betTh*(1+(1-e)*phi0*Phi(e));
Q1 = subs(Q1,e,bd01Inv(e));
Q = symfun(Q1,e);


% Construct functions to get derivatives of Q(e)

DQ2 = sym('DQ2',[ord,1],'real');    % matrix to hold derivatives of Q

dffQ = Q;
for j = 1:ord
    dffQ = diff(dffQ,e);
    DQ2(j,:) = subs(dffQ,e,bd01(e_));
end

% create m-function that takes n_ as input and outputs Q derivatives
flnm = ['fn_BGPEx_QDerv_ord' num2str(ord)];   % name of function
matlabFunction(DQ2,'File',flnm,'Vars',{prs},'Optimize',codeopt);


%% Steady state function

X_ = psi*F(e_,z_)/del;
Y_ = F(e_,z_);
C_ = X_+Y_;
lm_ = ((1-gam)*C_)^(-om);
Om_ = e_^phie*lm_;
io_ = (1-gam)*C_;

argSS = [X_;Y_;lm_;Om_;io_];

flnm = 'fn_BGPEx_SS';
matlabFunction(argSS,'File',flnm,'Vars',{prs},'Outputs',{'argSS'},'Optimize',codeopt);


