function errvc = fn_BGPEx_EulErr(yvc,tvc,epvc,prs,cfcl,OP)
%
% This function computes Euler errors.
% 
% Inputs:
%   yvc         ny-by-J matrix, where each column represents a vector of
%                   date-t endogenous state variables (y)
%   tvc         nt-by-J matrix, where each column represents a vector of
%                   date-t exogenous state variables (th)
%   epvc        nt-by-K matrix, where each column is a simulated vector
%                   of innovations to the stochastic processes at t+1
%   prs         vector of parameter values
%   cfcl        Taylor coefficients from "collapsed" solution
%   OP          struct containing other model variables
%
% Outputs:
%   errvc       vector of Euler errors
%
% Note: the following functions must be in the same directory in order to
% run this script (see CodeDescription.pdf for descriptions):
%
%   - TaylSim_tX.m
%
% Outputs:
%   errvc       J-by-1 vector of Euler errors
%
% For Galizia (2020), �Saddle Cycles: Solving Rational Expectations Models
%   Featuring Limit Cycles (or Chaos) Using Perturbation Methods�

%% Initialize

J = size(yvc,2);    % number of Euler errors to be computed
K = size(epvc,2);   % number of simulations

rho = prs(OP.irho); % autocorrelations
sig = prs(OP.isig); % s.d.'s of innovations

con = true; % flag to get constant term in Taylor simulations
nord = OP.ord+1;    % total number of Taylor orders (incl. constant)

ce = cfcl(:,OP.e);  % Taylor coefficients for e policy function

p = fn_BGPEx_prsStr(prs,'VtoS'); % convert parameter vector to struct

% steady state values
argSS = fn_BGPEx_SS(prs);
X_ = argSS(1);
Y_ = argSS(2);
y_ = [X_;Y_];
e_ = p.e_;
te_ = -log(1/e_ - 1);
betTh = e_^(-p.phie)/(1+(1-e_)*p.phi0*p.Phi0);

% extract parameters
al = p.al;
del = p.del;
psi = p.psi;
gam = p.gam;
om = p.om;
phie = p.phie;

%% Compute errors

ntXk = OP.nSt0.^(0:OP.ord);  % vector of number of tensor product terms of each order
tind = [0,cumsum(ntXk)];    % vector of total number of tensor product terms up to each order
nc = sum(ntXk);             % total number of tensor product terms

% allocate memory
Hp = zeros(1,J);
e = zeros(1,J);
EOmp = zeros(1,J);

% initial state vectors in levels (rather than log-dev from SS)
X = X_.*exp(yvc(1,:));
Y = Y_.*exp(yvc(2,:));

H = X/(1-p.del) + (1-p.psi/(1-p.del))*Y; % useful quantity

parfor i = 1:J      % for each state vector
    
    yi = yvc(:,i);    % extract i-th endogenous state vector
    ti = tvc(:,i);    % extract i-th exogenous state vector
    tX = TaylSim_tX([yi;ti],tind,nc,con,nord);  % tensor products of current state variables
    
    eld = ce.'*tX;     % Taylor approximation for (transformed) e 
    e(i) = 1./(exp(-(eld + te_))+1);    % un-transform
    
    % next-period states implied by appoximation for e
    Ypi = exp(ti(1))*e(i)^al;       
    Xpi = (1-del)*X(i) + psi*Ypi;
    ypi = log([Xpi;Ypi]./y_);   % in log-deviations
    
    % simulated next-period exogenous variables
    tpi = rho.*ti + sig.*epvc;
    
    % get implied next-period solution for each realiziation of exogenous
    % variables
    tXp = zeros(nc,K);
    for j = 1:K
        tXp(:,j) = TaylSim_tX([ypi;tpi(:,j)],tind,nc,con,nord);  % tensor products of future state variables
    end
    epi = 1./(exp(-(ce.'*tXp + te_))+1);
    Hp(i) = X(i) + Ypi;
    lmpi = (Hp(i) - gam*H(i))^(-om);
    Ompi = (epi.^phie).*lmpi;
    
    EOmp(i) = mean(Ompi,2); % mean from Monte Carlo simulation
        
end

% compute Euler error
Phi = p.Phi0*exp((p.Phi2/p.Phi0)*(e-e_).^2/2 + (p.Phi3/p.Phi0)*(e-e_).^3/6);
Q = betTh*(1+p.phi0*(1-e).*Phi);
errvc = (((Q.*EOmp)./exp(tvc(2,:))).^(-1/p.om) + p.gam*H)./Hp - 1;





